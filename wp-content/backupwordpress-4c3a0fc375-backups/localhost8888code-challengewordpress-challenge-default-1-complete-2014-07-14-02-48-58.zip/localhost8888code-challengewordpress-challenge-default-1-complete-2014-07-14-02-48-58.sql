# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-07-07 23:24:36', '2014-07-07 23:24:36', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=323 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (153 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888/Code-challenge/Wordpress-Challenge', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Treehouse Worpress Challenge', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'alex.chavet@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'closed', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'comment_moderation', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (32, 'active_plugins', 'a:1:{i:0;s:35:"backupwordpress/backupwordpress.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'home', 'http://localhost:8888/Code-challenge/Wordpress-Challenge', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'alexchavet', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'alexchavet', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '250', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '250', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:4:{i:1;a:0:{}i:2;a:3:{s:5:"title";s:9:"Copyright";s:4:"text";s:94:"Design : alexchavet ©<br>
Starter theme : _S themes<br>
Made for : Treehouse code challenge";s:6:"filter";b:0;}i:3;a:3:{s:5:"title";s:9:"Follow me";s:4:"text";s:293:"<ul id="follow_me">
<li><i class="fi-social-facebook"></i>Facebook</li>
<li><i class="fi-social-twitter"></i>Twitter</li>
<li><i class="fi-social-treehouse"></i>Treehouse</li>
<li><i class="fi-social-github"></i>Github</li>
<li><i class="fi-social-instagram"></i>Instagram</li>
</ul>

";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '7', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:4:{i:0;s:17:"recent-comments-2";i:1;s:8:"search-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";}s:9:"sidebar-1";a:3:{i:0;s:10:"nav_menu-2";i:1;s:6:"text-3";i:2;s:6:"text-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'cron', 'a:7:{i:1405323060;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1405337084;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1405378800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1405380374;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1405381425;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1405825200;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1405305996;s:15:"version_checked";s:5:"3.9.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1405305997;s:7:"checked";a:4:{s:10:"alexchavet";s:9:"1.0-wpcom";s:14:"twentyfourteen";s:3:"1.1";s:14:"twentythirteen";s:3:"1.2";s:12:"twentytwelve";s:3:"1.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, '_transient_random_seed', 'a0bfbc3df6501ad45fc5c83ac0dec41f', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'auth_key', '[!5,.HUt*X0B0ayPh +x)8>vRBsj]#{E58R|ttx,]R#GmE$2dkuaZu4oiQ+#~dVV', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'auth_salt', 'L+y9Ys)PZ.=5#Ji*$wCA;>5Q{{A|l0p-)f(3*0^{jt`8K8y;H0bH[<&w%xtf6m@?', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'logged_in_key', 'AyM2GZm^8sF3,2.6>RkE-,ndZM};|6*&mk{_Ktn`#1~;,awXbOm:dLI#c?9T`brK', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'logged_in_salt', 'Q3Pv<Le ksGm@*]lVk8lDe{p>8}JYtO[@)LeO)F++#tvUbnRygI8bOjV ]FB^zS9', 'yes') ; 
INSERT INTO `wp_options` VALUES (109, 'nonce_key', 'ElnW8W/:(m)$g}i@r!MD1n1h&,bc2~Y$|W[ya[6;?rosS2$H8M6?6qagkdenVB;Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (110, 'nonce_salt', 'zfe#aYJIKd8GTeBbWT#_(pyMM]s]if;zdf$5IdtC1mIyMZ;zR1Ul:/~W|E8a7jTF', 'yes') ; 
INSERT INTO `wp_options` VALUES (111, '_site_transient_timeout_browser_415432f8a69810436cc04440121d795d', '1405380375', 'yes') ; 
INSERT INTO `wp_options` VALUES (112, '_site_transient_browser_415432f8a69810436cc04440121d795d', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"35.0.1916.153";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (115, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (132, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1404775588;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (133, 'current_theme', 'alexchavet', 'yes') ; 
INSERT INTO `wp_options` VALUES (134, 'theme_mods_alexchavet', 'a:8:{i:0;b:0;s:16:"header_textcolor";s:6:"000000";s:16:"background_color";s:6:"ffffff";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (135, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (146, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (147, 'widget_nav_menu', 'a:3:{i:1;a:0:{}i:2;a:2:{s:5:"title";s:4:"Menu";s:8:"nav_menu";i:2;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (150, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:1:{i:0;i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (188, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (222, 'rewrite_rules', 'a:68:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (267, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1405334242', 'no') ; 
INSERT INTO `wp_options` VALUES (268, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:27:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=4.0-beta1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4025:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="http://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3077:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23298:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/lkwdwrd">Luke Woodward</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2967:"<p><a href="//wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="//wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="//core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="//make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="//make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8217;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 13 Jul 2014 22:37:22 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 10 Jul 2014 10:27:22 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130910180210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (269, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1405334242', 'no') ; 
INSERT INTO `wp_options` VALUES (270, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1405291042', 'no') ; 
INSERT INTO `wp_options` VALUES (271, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1405334244', 'no') ; 
INSERT INTO `wp_options` VALUES (272, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WordPress.tv: Dan Beil: How NOT to Develop (With WordPress)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36416";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.tv/2014/07/13/dan-beil-how-not-to-develop-with-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:664:"<div id="v-mwFhKpDW-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36416/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36416/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36416&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/13/dan-beil-how-not-to-develop-with-wordpress/"><img alt="Dan Beil: How NOT to Develop (With WordPress)" src="http://videos.videopress.com/mwFhKpDW/video-09ce81fb50_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Jul 2014 15:55:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WordPress.tv: Andrei Chira: Cum mi-a schimbat WordPress viața";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36533";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://wordpress.tv/2014/07/13/andrei-chira-cum-mi-a-schimbat-wordpress-viat%cc%a6a/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:672:"<div id="v-aSN3u5nN-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36533/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36533/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36533&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/13/andrei-chira-cum-mi-a-schimbat-wordpress-viat%cc%a6a/"><img alt="Andrei Chira: Cum mi-a schimbat WordPress viața" src="http://videos.videopress.com/aSN3u5nN/video-cfa4d6f800_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Jul 2014 15:28:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WordPress.tv: Ivan Potančok: Less, Bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36481";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.tv/2014/07/13/ivan-potancok-less-bootstrap/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:630:"<div id="v-NjK2dLXJ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36481/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36481/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36481&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/13/ivan-potancok-less-bootstrap/"><img alt="Ivan Potančok: Less, Bootstrap" src="http://videos.videopress.com/NjK2dLXJ/video-be1dc90ddf_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Jul 2014 15:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress.tv: Martin Viceník: Video a WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36310";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.tv/2014/07/12/martin-vicenik-video-a-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:643:"<div id="v-Hxbb4DLf-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36310/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36310/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36310&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/12/martin-vicenik-video-a-wordpress/"><img alt="Martin Viceník: Video a WordPress" src="http://videos.videopress.com/Hxbb4DLf/video-4c0e0f61b6_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 15:58:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WordPress.tv: Yoav Farhi: Language Packs and the Future of WordPress Translations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36412";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2014/07/12/yoav-farhi-language-packs-and-the-future-of-wordpress-translations/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:704:"<div id="v-mUPafAmJ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36412/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36412/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36412&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/12/yoav-farhi-language-packs-and-the-future-of-wordpress-translations/"><img alt="Yoav Farhi: Language Packs and the Future of WordPress Translations" src="http://videos.videopress.com/mUPafAmJ/video-2813feab06_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 15:58:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WordPress.tv: Almog Baku: Optimizing and Improving Performance in WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=19153";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wordpress.tv/2014/07/12/almog-baku-optimizing-and-improving-performance-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:698:"<div id="v-Jl4CDEqK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/19153/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/19153/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=19153&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/12/almog-baku-optimizing-and-improving-performance-in-wordpress/"><img alt="Almog Baku: Optimizing and Improving Performance in WordPress" src="http://videos.videopress.com/Jl4CDEqK/video-813f1ede0d_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 15:42:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: A Proposed Enhancement That Saves A Mouse Click When Upgrading WordPress Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26203";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/a-proposed-enhancement-that-saves-a-mouse-click-when-upgrading-wordpress-plugins?utm_source=rss&utm_medium=rss&utm_campaign=a-proposed-enhancement-that-saves-a-mouse-click-when-upgrading-wordpress-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1940:"<p>Four months ago, WordPress user <a title="https://profiles.wordpress.org/Fredelig" href="https://profiles.wordpress.org/Fredelig">Fredelig</a> <a title="https://core.trac.wordpress.org/ticket/27303" href="https://core.trac.wordpress.org/ticket/27303">created a new ticket</a> on WordPress trac suggesting the plugin update notification bubble load the page listing all of the plugins with pending upgrades.</p>
<p>In WordPress 3.9, clicking the notification loads Plugins.php which lists all of the activated plugins, including the ones with upgrades. This requires a second mouse click to show only the plugins that have an update available. Although it was too late to include in WordPress 3.9, it&#8217;s also missed the boat for 4.0.</p>
<div id="attachment_26260" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/MoreUsefulPluginUpgradeBubble.png" rel="prettyphoto[26203]"><img class="size-full wp-image-26260" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/MoreUsefulPluginUpgradeBubble.png?resize=621%2C131" alt="Better Plugin Upgrade Notification Bubbles" /></a><p class="wp-caption-text">Better Plugin Upgrade Notification Bubbles</p></div>
<p>On a related note, I&#8217;d like to propose an enhancement to the comment notification bubble. Clicking on the notification currently loads edit-comments.php which displays both approved and moderated comments. Ninety-nine percent of the time when I click on the notification link, it&#8217;s because I want to approve a comment pending moderation.</p>
<p>Although the task can be accomplished with the way it works now, sometimes the comment I need to approve is not on the first page and I have to click the Pending comments link. Having the notifications bubble load the pending comments first would save me a mouse click.</p>
<p><strong>Do you have any pros or cons regarding the suggested enhancements?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 06:37:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: WPWeekly Episode 154 – All About The Customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=26192&preview_id=26192";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/wpweekly-episode-154-all-about-the-customizer?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-154-all-about-the-customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2656:"<p>On this episode of WordPress Weekly, we give you the low down on all the new features in WordPress 4.0 beta 1. Later in the show, <a href="http://wp.mattwie.be/" title="http://wp.mattwie.be/">Matt Wiebe</a> who works for Automattic as a design engineer, joins us to discuss his thoughts on the WordPress customizer. Most of what we talked about stems from his <a href="http://wp.mattwie.be/2014/06/27/evolving-the-customizer/" title="http://wp.mattwie.be/2014/06/27/evolving-the-customizer/">recent blog post</a> highlighting some of the roadblocks the customizer has in its current state. Near the end of the show, we have a candid conversation on how the feature may evolve in the next 2-3 years. After the interview, I&#8217;m more optimistic of what the future holds for the customizer.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/preview-wordpress-4-0-features-beta-1-now-available-for-testing" title="http://wptavern.com/preview-wordpress-4-0-features-beta-1-now-available-for-testing">Preview WordPress 4.0 Features, Beta 1 Now Available for Testing</a><br />
<a href="http://wptavern.com/wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores" title="http://wptavern.com/wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores">WordPress.tv Adds Its First German Presentation: Konstantin Obenland on Underscores</a><br />
<a href="http://wptavern.com/wordpress-feature-plugin-planned-to-improve-image-editing-experience" title="http://wptavern.com/wordpress-feature-plugin-planned-to-improve-image-editing-experience">WordPress Feature Plugin Planned to Improve Image Editing Experience</a><br />
<a href="http://wptavern.com/wpbeginner-turns-5-celebrates-with-campaign-to-build-two-new-schools-in-guatemala" title="http://wptavern.com/wpbeginner-turns-5-celebrates-with-campaign-to-build-two-new-schools-in-guatemala">WPBeginner Turns 5, Celebrates With Campaign To Build Two New Schools In Guatemala</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, July 18th 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #154:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 02:34:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WPTavern: Gust Plugin Adds Support for Categories, Featured Images and Custom Post Types";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26217";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:218:"http://wptavern.com/gust-plugin-adds-support-for-categories-featured-images-and-custom-post-types?utm_source=rss&utm_medium=rss&utm_campaign=gust-plugin-adds-support-for-categories-featured-images-and-custom-post-types";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3760:"<p>The <a href="http://wordpress.org/plugins/gust/" target="_blank">Gust</a> plugin aims to provide a <a href="https://ghost.org/" target="_blank">Ghost</a>-style publishing experience within the WordPress admin. It was released at the end of last year by developer Arūnas Liuiza. He was disappointed that Ghost didn&#8217;t end up being a fork of WordPress, so he decided to package its best publishing features into a plugin. Gust adds a Ghost-style editor with a live preview pane to WordPress and includes support for Markdown.</p>
<p>Liuiza has been gradually improving the plugin and the 0.4.0 release is a total rewrite with several new features since the last time we <a href="http://wptavern.com/gust-plugin-brings-the-ghost-admin-panel-into-wordpress" target="_blank">featured</a> it on the Tavern. It&#8217;s now PHP 5.2 compatible. In addition to media upload capabilities, Gust now supports adding and assigning a featured image.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-featured-image.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-featured-image.jpg?resize=1025%2C585" alt="edit-featured-image" class="aligncenter size-full wp-image-26224" /></a></p>
<p>The latest version includes the ability to create and add categories in addition to tags.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/category-support.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/category-support.jpg?resize=1004%2C643" alt="category-support" class="aligncenter size-full wp-image-26218" /></a></p>
<p>Gust 0.4.0 adds autosave support so you don&#8217;t have to worry about saving your drafts as you are composing. This release includes support for custom fields (post meta) and adds experimental support for custom post types. You can enable that feature via the plugin&#8217;s settings page.</p>
<p>In the past, the Gust dashboard was difficult to find unless you knew how to navigate there. The latest release improves the discoverability of the Gust dashboard by adding tighter integration with the WordPress admin bar and post edit links.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/gust-dashboard.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/gust-dashboard.jpg?resize=640%2C168" alt="gust-dashboard" class="aligncenter size-full wp-image-26219" /></a></p>
<p>You can easily edit any of your content in the Gust dashboard by clicking on the new link in the hover menu below posts/pages/CPTs.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-posts.jpg" rel="prettyphoto[26217]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-posts.jpg?resize=833%2C276" alt="edit-posts" class="aligncenter size-full wp-image-26221" /></a></p>
<p>Gust is by no means a perfect of full-featured editing experience, but it is a solid option for adding Markdown support with a live preview. Not every user likes the same flavor of WordPress and Gust adds an interesting alternative to the current publishing experience. In the future, we may see many more variations of the WordPress editor as the platform adds better support for interfacing with external apps.</p>
<p>If you like where the plugin is headed and want to help contribute, you can find Gust on <a href="https://github.com/ideag/gust" target="_blank">GitHub</a>. So far, it has received excellent ratings on WordPress.org and Liuiza has been adding regular improvements. You can download <a href="http://wordpress.org/plugins/gust/" target="_blank">Gust</a> for free via the plugin installer in the WordPress admin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Jul 2014 00:09:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: THBusiness: A Free WordPress Business Theme Based on Bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26181";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/thbusiness-a-free-wordpress-business-theme-based-on-bootstrap?utm_source=rss&utm_medium=rss&utm_campaign=thbusiness-a-free-wordpress-business-theme-based-on-bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3206:"<p>If you&#8217;re looking for a clean, customizable business theme for WordPress, <a href="http://wordpress.org/themes/thbusiness" target="_blank">THBusiness</a> just landed in the official Themes Directory. While most free themes are dedicated to blogging, THBusiness is focused on providing all of the basic elements you need to display featured content, services, testimonials, and more.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/THbusiness.png" rel="prettyphoto[26181]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/THbusiness.png?resize=880%2C660" alt="THbusiness" class="aligncenter size-full wp-image-26186" /></a></p>
<p>It was designed by the folks at <a href="http://www.themezhut.com/" target="_blank">THEMEZHUT</a> to have a big visual impact on the homepage. The theme is based on <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a> and includes a full width Flexslider, which can be easily configured in the options panel.</p>
<p>Most of the layout is managed by widgets. THBusiness includes a total of eight different widget areas, with four of them located on the homepage.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/widgets.jpg" rel="prettyphoto[26181]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/widgets.jpg?resize=944%2C256" alt="widgets" class="aligncenter size-full wp-image-26183" /></a></p>
<p>It also includes six business-specific widgets that make it easy to set up featured images, services, testimonials, a call to action, and recent work. THBusiness has support for <a href="http://fortawesome.github.io/Font-Awesome/" target="_blank">Font Awesome</a> icons and adding them to the widgets doesn&#8217;t require adding any extra markup.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/recent-work-testimonials.jpg" rel="prettyphoto[26181]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/recent-work-testimonials.jpg?resize=805%2C784" alt="recent-work-testimonials" class="aligncenter size-full wp-image-26198" /></a></p>
<p>The options panel lets you easily add a custom logo, favicon, and footer description. Check out a <a href="http://www.themezhut.com/demo/thbusiness/" target="_blank">live demo of THBusiness</a> to see it in action.</p>
<p>Using THBusiness means that you can take advantage of any of the Bootstrap components such as labels, alerts, thumbnails, buttons, badges and more. While not everyone is a fan of reusable UI components, they can help to keep a website&#8217;s look consistent. If you&#8217;re not a designer, working with a frontend framework like <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a> makes it easy to mix in different UI elements without having to reinvent the wheel.</p>
<p><a href="http://wordpress.org/themes/thbusiness" target="_blank">THBusiness</a> is a clean business theme that doesn&#8217;t pack in a lot of complicated options. It&#8217;s easy to setup by dropping widgets into the homepage widget areas and you can have your site looking like the demo in a matter of minutes. Download it for free through your WordPress admin theme browser.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Jul 2014 18:13:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"Post Status: Tips for local WordPress development with Varying Vagrant Vagrants (VVV)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6848";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://www.poststat.us/vvv-tips-every-day/?utm_source=rss&utm_medium=rss&utm_campaign=vvv-tips-every-day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6721:"<p><img class="aligncenter size-large wp-image-6861" src="http://www.poststat.us/wp-content/uploads/2014/07/vvv-tips-752x300.jpg" alt="vvv-tips" width="752" height="300" />I’ve used local development environments for as long as I can remember.  They’ve always been a fluid part of being a developer.  The biggest pain point was keeping everything upgraded at all times and switching from one stack to another.</p>
<p>In case you didn’t notice, I said ”was”.  This is because in the Spring of 2013 I found Varying Vagrant Vagrants, or <a href="https://github.com/Varying-Vagrant-Vagrants/VVV">VVV</a>.  With VVV you can have your local WordPress development environment virtually silo’d in it’s own container.</p>
<p>There are many tutorials out there explaining the <a href="http://chriswiegman.com/2013/08/virtual-machines-the-holy-grail-of-local-web-development/">what and why you should use a virtualized development environment</a>, <a href="https://docs.vagrantup.com/v2/getting-started/">how to setup Vagrant</a>, and <a href="http://wptavern.com/wordpress-theme-review-vvv-a-quick-vagrant-setup-for-testing-and-reviewing-themes">how to setup VVV</a> so I won’t dive deep there.</p>
<p>My take away is just that I want to be able to have an environment that’s flexible, quick, and not so dependent upon the hardware and software installed on my computer.</p>
<p>With that, here are my most used tips for everyday usage of VVV.  I do mention some of the initial pain points I had with VVV, but with some digging around I found solutions that I would like to share with you.</p>
<h3>1. Creating a new site</h3>
<p>TL;DR <code>vvv new mysite.dev -v 3.9.1</code></p>
<p>I’m not a systems engineer by any means.  I know enough to be helpful, but not enough to build a full stack.  So when I jumped into VVV for the first time, I had an issue with trying to get my existing sites into the /www root directory.</p>
<p>The way I work is that I have a /Sites directory, then under that is each website that I am working on.  When I installed VVV for the first time, I installed it in that /Sites folder only to realize that I probably should’ve installed it outside of that.</p>
<p>But that was an easy fix.  <code>vagrant destroy</code> and start again where I wanted.</p>
<p>Once I created a site or two I realized that I wanted to automate this process a bit more than the <a href="https://github.com/Varying-Vagrant-Vagrants/VVV/wiki/Auto-site-Setup">Auto site Setup</a> that VVV has built in.  After a quick search I found <a href="https://github.com/aliso/vvv-site-wizard">VVV Site Wizard</a>.</p>
<p>This great script allowed me to create a new site with any version of WP I wanted simply by typing <code>vvv new mysite.dev -v 3.9.1</code> where the -v grabs the version of WordPress I want and installs it.  If left off, then it’ll grab the latest.</p>
<p>I didn’t have to mess with database or nginx files, or provision scripts either.  After typing in that simple command, I had a brand new site installed and ready to go in seconds.</p>
<h3>2. Connecting to MySQL</h3>
<p>At first glance, I was unsure on using MySQL as I had in the past since I didn’t like using phpMyAdmin for database work.  I like to use Sequel Pro (on OS X) to run queries and look at the data.</p>
<p>I wasn’t sure how I was going to connect to MySQL since normally I would just put in my connection string with the host information and it would connect.  With VVV I wouldn’t be able to put in localhost and the user credentials and have it connect, since technically my sites were no longer on my localhost.</p>
<p>The way to do it is via <a href="https://github.com/Varying-Vagrant-Vagrants/VVV/wiki/Connecting-to-MySQL#ssh-tunnel">SSH Tunnel</a>.  In layman&#8217;s terms, that’s just relaying the information via SSH.</p>
<p>So whether you are using Sequel Pro or some other MySQL application, look for SSH Tunnel when setting up your connection.</p>
<p>Here&#8217;s what mine looks like:</p>
<div id="attachment_6852" class="wp-caption aligncenter"><img class="wp-image-6852 size-full" src="http://www.poststat.us/wp-content/uploads/2014/07/sequel-pro-vvv.png" alt="sequel-pro-vvv" width="454" height="470" /><p class="wp-caption-text">Yes I know it&#8217;s bad practice to have root user, but if you have my laptop, then it doesn&#8217;t matter what the password is.</p></div>
<h3>3. Restarting Services</h3>
<p>This isn’t something that I do all that often, but there are times that I will need to do this often enough that I wanted to share it.</p>
<p>Sometimes when I run <code>vagrant up</code> MySQL doesn’t start and I’ll get the WordPress “Error Establishing a Database Connection”.</p>
<p>With two commands, this is easily fixed.  First type <code>vagrant ssh</code> and then type <code>sudo service mysql start</code>.  After a few seconds, you should be good to go.</p>
<p>One of the great features of VVV is that unless you destroy your setup, any changes you make within the instance will persist.  So there are times when I have to setup custom nginx directives and restart the service.</p>
<p><code>sudo service nginx restart</code> does the trick.</p>
<h4>Clean slate</h4>
<p>After a long day of WordPress development, it’s great to just type <code>vagrant halt</code>, watch my resources come back available, and know that my laptop is free of any development environment burden.</p>
<p>Since 2013 when I really went neck deep into virtualizing my development environment, I can’t tell you how awesome it is to see the WordPress community embracing this as well.  This only serves us as developers more ability to push forward with the latest and greatest plugins, themes, and core as the architectures we work on mature.</p>
<div id="single-hcard-jasonresnick" class="loop-meta vcard"><h4 class="author-bio fn n">Jason Resnick</h4><div class="author-description"><img alt="Jason Resnick" src="http://0.gravatar.com/avatar/022e1ac79e7186ee6ef38c3916388aa0?s=150&d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D150&r=G" class="avatar avatar-150 photo" height="150" width="150" /><div class="user-bio author-bio">Jason Resnick is a WordPress developer, founder of <a href="http://rezzz.com">rezzz.com</a> &amp; <a href="http://www.rezzz.com/wp-field-guides">WP Field Guides</a> and is a co-host of the WordPress development podcast <a href="http://wpdevtable.com">WP Dev Table</a>. Jason is a sports nut, even if all the teams he follows seem to lose.  Follow Jason on Twitter <a href="https://twitter.com/rezzz">@rezzz</a></div><!-- .user-bio .author-bio --></div><!-- .loop-description --></div><!-- .loop-meta -->";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Jul 2014 17:45:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jason Resnick";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress.tv: Zac Gordon: Why Setting Up Themes Is a Niche in Itself, What to Know";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36328";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2014/07/11/zac-gordon-why-setting-up-themes-is-a-niche-in-itself-what-to-know/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:711:"<div id="v-CWraOJk1-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36328/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36328/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36328&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/11/zac-gordon-why-setting-up-themes-is-a-niche-in-itself-what-to-know/"><img alt="Zac Gordon: Why Setting Up Themes Is a Niche in Itself, What to Know" src="http://videos.videopress.com/CWraOJk1/video-898f08d1db_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Jul 2014 15:53:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress.tv: Kelly Dwan: A Walk Around the Loop";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36414";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.tv/2014/07/11/kelly-dwan-a-walk-around-the-loop/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:644:"<div id="v-Gkb8CYeW-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36414/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36414/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36414&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/11/kelly-dwan-a-walk-around-the-loop/"><img alt="Kelly Dwan: A Walk Around the Loop" src="http://videos.videopress.com/Gkb8CYeW/video-2bc80f3c10_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Jul 2014 15:31:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WordPress.tv: Gloria Antonelli: Information Architecture Strategy Session";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36324";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://wordpress.tv/2014/07/11/gloria-antonelli-information-architecture-strategy-session/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:694:"<div id="v-HdYmQ5Yt-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36324/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36324/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36324&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/11/gloria-antonelli-information-architecture-strategy-session/"><img alt="Gloria Antonelli: Information Architecture Strategy Session" src="http://videos.videopress.com/HdYmQ5Yt/video-e4ee1f9bf5_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Jul 2014 15:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: Nantes, France to Host a WordCamp for Developers in November";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26144";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/nantes-france-to-host-a-wordcamp-for-developers-in-november?utm_source=rss&utm_medium=rss&utm_campaign=nantes-france-to-host-a-wordcamp-for-developers-in-november";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3339:"<div id="attachment_26166" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/nantes.jpg" rel="prettyphoto[26144]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/nantes.jpg?resize=1025%2C681" alt="Nantes" class="size-full wp-image-26166" /></a><p class="wp-caption-text">Nantes</p></div>
<p>France is getting its second official WordCamp. The event is called <a href="http://2014.wptech.fr/" target="_blank">WordCamp Nantes WP Tech</a> and will be held in Nantes on Saturday, November 29, 2014. Unlike your traditional WordCamp, WP Tech will be devoted entirely to developers.</p>
<p><strong>&#8220;The idea is to share knowledge, ideas and best practices about WordPress development,&#8221;</strong> organizer Daniel Roch told the Tavern. &#8220;It&#8217;s slightly different from a basic WordCamp because there will only be one track about development.&#8221;</p>
<p>Roch is joined by four others on the organization team and they are expecting 100-300 attendees at <a href="http://www.epitech.eu/" target="_blank">Epitech</a>, a school for computer innovation. &#8220;All of us thought that there weren&#8217;t enough technical conferences about WordPress. In fact, we spoke with many developers, and all of them were enjoying the idea of a WordCamp Developer Edition.&#8221;</p>
<div id="attachment_26151" class="wp-caption alignright"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/venue-nantes.jpg" rel="prettyphoto[26144]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/venue-nantes.jpg?resize=300%2C225" alt="La salle de l’Epitech Nantes" class="size-medium wp-image-26151" /></a><p class="wp-caption-text">La salle de l’Epitech Nantes</p></div>
<p>The selected venue is located in the center of downtown Nantes, as the event was born out of <a href="http://www.wp-nantes.org/" target="_blank">WP Nantes</a>, a thriving local meetup group. The organizers are looking for passionate speakers to present on technical topics. &#8220;It doesn&#8217;t matter if you&#8217;re an expert about your topic,&#8221; Roch said. &#8220;You must be passionate! Concerning the topics, we&#8217;re looking for presentations on coding best practices, security, performance, APIs, etc.&#8221;</p>
<p>WP Tech organizers are considering adding a contributor day, but Roch said they don&#8217;t wish to stretch themselves too thin for the first event. &#8220;It would be great for us to have a contributor day, but we are afraid to bite off more than we can chew. We think it&#8217;s better to have a smaller yet well organized event, rather than a disappointing one.&#8221; They remain undecided about adding a contributor day.</p>
<p>The call for speakers is already open and those selected will be paid for travel and hotel. Presentations will be given in both English and French. Applications to speak will be closed Tuesday, July 15, at midnight.  <a href="http://2014.wptech.fr/appel-orateurs/" target="_blank">Contact the organizers</a> if you wish to participate. Developers, designers and project managers are all encouraged to attend WP Tech to learn more about mastering WordPress. Sign up on the event&#8217;s <a href="http://2014.nantes.wordcamp.org/" target="_blank">WordCamp site</a> (coming soon) to be notified of updates.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 21:37:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: Blue Steel: A Free WordPress Theme Based on Roots";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26074";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:160:"http://wptavern.com/blue-steel-a-free-wordpress-theme-based-on-roots?utm_source=rss&utm_medium=rss&utm_campaign=blue-steel-a-free-wordpress-theme-based-on-roots";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3325:"<p><a href="http://roots.io/" target="_blank">Roots</a> is a WordPress starter theme that makes use of HTML5 Boilerplate, Bootstrap, and Grunt. Over the years Roots has garnered somewhat of a cult following and is still going strong with the release of <a href="http://roots.io/roots-7-0-0-updates/" target="_blank">version 7.0.0</a> last week. This release moves some of the theme&#8217;s trademark features into a plugin called <a href="http://wptavern.com/soil-roots-framework-features-that-can-be-used-with-any-wordpress-theme" target="_blank">Soil</a> and adds Bower for front-end package management.</p>
<p>Blue Steel is a new open source theme built to run on top of Roots. It was inspired by the design of <a href="http://www.theverge.com/" target="_blank">The Verge</a> and, of course, the film <a href="https://www.youtube.com/watch?v=D519hT7-ytY" target="_blank">Zoolander</a>. <a href="https://twitter.com/dhawalhshah" target="_blank">Dhawal Shah</a> introduced his new theme on the Roots discussion boards under a <a href="http://discourse.roots.io/t/new-roots-theme-blue-steel-mit-license/1905" target="_blank">thread</a> titled: <strong>&#8220;Is there more to a blog than being really really really ridiculously good looking?&#8221;</strong></p>
<p>Blue Steel is the answer to that question. It was originally created for use on <a href="https://www.class-central.com/" target="_blank">Class Central</a>, a website dedicated to helping people discover free online classes (MOOCs) from top universities such as Stanford, MIT, and Harvard.</p>
<p>The theme is responsive and resizes down nicely to use mobile-friendly navigation. The <a href="https://www.class-central.com/report/" target="_blank">homepage</a> sports a flat, minimalist style with bold colors and features your latest content with room for a sidebar.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/homepage.jpg" rel="prettyphoto[26074]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/homepage.jpg?resize=764%2C626" alt="homepage" class="aligncenter size-full wp-image-26135" /></a></p>
<p>Blue Steel <a href="https://www.class-central.com/report/udacity-kunal-chawla/" target="_blank">blog posts</a> are styled with readable typography and attractive pullquotes.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/blue-steel-blog-posts.jpg" rel="prettyphoto[26074]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/blue-steel-blog-posts.jpg?resize=1025%2C698" alt="blue-steel-blog-posts" class="aligncenter size-full wp-image-26131" /></a></p>
<p>This is not exactly your average plug-and-play style WordPress theme. In order to use it you must be familiar with both <a href="http://roots.io/" target="_blank">Roots</a> and <a href="https://getcomposer.org/" target="_blank">Composer</a>. You will also be required to modify it to suit your own needs, but it does provide an excellent starting place for creating your own Roots-powered theme.</p>
<p>Blue Steel is released under a GPL-compatible MIT license. Many thanks to the folks at <a href="http://codelight.eu/" target="_blank">Codelight</a> who decided to make it available on <a href="https://github.com/classcentral/blue-steel" target="_blank">GitHub</a> so anyone can fork it for an easy start.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 20:09:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WPTavern: WordPress Mini Conference “East Meets Press” Set For September 17-21, 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26058";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/wordpress-mini-conference-east-meets-press-set-for-september-17-21-2014?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-mini-conference-east-meets-press-set-for-september-17-21-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2444:"<p><a title="http://eastmeetspress.com/" href="http://eastmeetspress.com/">East Meets Press</a> is a business focused WordPress event organized by Ben Fox that will be held on <strong>September 17-21</strong> (Wednesday to Sunday – 4 nights). Not to be outdone by BeachPress which was recently held on the West Coast of the US, East Meets Press will take place on the East Coast in Kure Beach, North Carolina.</p>
<div id="attachment_26110" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/EastMeetsPressVenue.jpg" rel="prettyphoto[26058]"><img class="size-full wp-image-26110" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/EastMeetsPressVenue.jpg?resize=550%2C365" alt="The Venue For East Meets Press" /></a><p class="wp-caption-text">The Venue For East Meets Press</p></div>
<p>Individual tickets are <strong>$600.</strong> The tickets are all-inclusive so they cover lodging, internet, food, and beverages. Companies that can&#8217;t attend but want to support the event can do so with the <strong>$400</strong> sponsor ticket.</p>
<p>Without the hustle and bustle of attending sessions and having limited networking time at a WordCamp, this event gives attendees a chance to get to know each another while discussing the business of WordPress in a relaxing atmosphere. There will be set meal times with a given topic of discussion as well as one 15 minute lightning talk each day. Outside of that, attendees will be free to do whatever they want.</p>
<p>It&#8217;s nice to see these type of events unfold within the WordPress community. They&#8217;re like miniature versions of <a title="http://wptavern.com/dates-announced-for-pressnomics-3-jan-22nd-24th-2015" href="http://wptavern.com/dates-announced-for-pressnomics-3-jan-22nd-24th-2015">PressNomics</a>. If you plan on going, let us know in the comments and be sure to <a title="http://eastmeetspress.com/?espresso_events=east-coast-press-2014" href="http://eastmeetspress.com/?espresso_events=east-coast-press-2014">register your tickets</a> as space is limited.</p>
<p>If you attended <a title="http://zao.is/2013/10/beachpress-2-0/" href="http://zao.is/2013/10/beachpress-2-0/">BeachPress 2014</a> or <a title="http://bigsnowtinyconf.com/" href="http://bigsnowtinyconf.com/">Big Snow Tiny Conference 2014,</a> I&#8217;d love to hear about your experience in the comments, especially if it improved your business.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 18:40:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Akismet: Akismet 3.0.1 for WordPress Now Available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1615";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://blog.akismet.com/2014/07/10/akismet-3-0-1-for-wordpress-now-available/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1574:"<p>Extry, extry, read all about it! Version 3.0.1 of <a href="http://wordpress.org/plugins/akismet/">the Akismet plugin for WordPress</a> is now available!</p>
<p>Even though it&#8217;s not a big round number like our 3.0 release, we&#8217;ve worked hard to make Akismet even better in 3.0.1:</p>
<ul>
<li>We&#8217;ve reduced the amount of data we store in the <code>akismet_as_submitted</code> comment meta value for each comment.</li>
<li>Akismet no longer depends on the <code>fsockopen</code> PHP function.</li>
<li>jQuery is no longer required for Akismet&#8217;s frontend JavaScript.</li>
<li>We fixed a bug that was causing spam reports from outside of the dashboard (the iOS app, for example) to be ignored.</li>
<li>If an API key is suspended for any reason, comments will now all be sent to the Pending queue instead of the Spam folder.</li>
<li>&#8230;and lots of other improvements to performance and error-handling.</li>
</ul>
<p>To upgrade, visit the Plugins or Updates page of your WordPress dashboard and follow the instructions. If you need to download the zip file directly, links to all versions are available in <a href="http://wordpress.org/plugins/akismet/">the WordPress plugins directory</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1615/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1615/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1615&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 17:45:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Christopher Finke";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Matt: 4 Years Working Remotely";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43867";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://ma.tt/2014/07/4-years-working-remotely/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:245:"<p>Sara Rosso writes <a href="http://whenihavetime.com/2014/07/08/10-lessons-from-4-years-working-remotely/">10 Lessons from 4 Years Working Remotely at Automattic</a>. (Lesson 11, left out: Always give list articles an odd number of items.)</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 16:13:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: Preview WordPress 4.0 Features, Beta 1 Now Available for Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26019";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:190:"http://wptavern.com/preview-wordpress-4-0-features-beta-1-now-available-for-testing?utm_source=rss&utm_medium=rss&utm_campaign=preview-wordpress-4-0-features-beta-1-now-available-for-testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4630:"<p><a href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/" target="_blank">WordPress 4.0 Beta 1</a> is now available for download and testing. This means that core developers are now onto the stage of bug fixes and inline documentation in preparation for the official release in <a href="http://make.wordpress.org/core/version-4-0-project-schedule/" target="_blank">August</a>.</p>
<p>Helen Hou-Sandí, the release lead, announced the beta with an outline of user-facing features that need testing. The list offers a good summary of some of the exciting changes and improvements coming in WordPress 4.0:</p>
<ul>
<li>Previews of oEmbed URLs in the visual editor and via the &#8220;Insert from URL&#8221; tab in the media modal.</li>
<li>Media library &#8220;grid view&#8221; added in addition to the &#8220;list view&#8221;</li>
<li>Refreshed plugin <a href="https://core.trac.wordpress.org/ticket/27440" target="_blank">install</a> and <a href="https://core.trac.wordpress.org/ticket/28785" target="_blank">search</a> experience</li>
<li>Select a language when installing WordPress</li>
<li>Improvements to editor resizing its top and bottom bars pin when needed</li>
<li>Improvements to keyboard and cursor interaction with <a href="https://core.trac.wordpress.org/ticket/28595" target="_blank">TinyMCE views</a></li>
<li>Widgets in the Customizer are now loaded in a separate panel</li>
<li>Improvements to formatting functions</li>
</ul>
<p>When testing the beta, you&#8217;ll find that the grid view for the media library is on by default. You have the option to toggle back to the list view, but I&#8217;m not sure why you ever would. The new grid view is truly a thing of beauty and has evolved considerably since last October when we <a href="http://wptavern.com/new-grid-view-coming-to-the-wordpress-media-library" target="_blank">featured</a> it during its initial development.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/grid-view.jpg" rel="prettyphoto[26019]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/grid-view.jpg?resize=966%2C582" alt="grid-view" class="aligncenter size-full wp-image-26087" /></a></p>
<p>The bulk edit option allows you to quickly delete multiple images. Clicking on individual items launches a details modal where you can edit an attachment and even navigate between items directly in the modal.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/details-modal.jpg" rel="prettyphoto[26019]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/details-modal.jpg?resize=718%2C542" alt="details-modal" class="aligncenter size-full wp-image-26089" /></a></p>
<p>There are a lot of changes packed into WordPress media in the upcoming release and any help testing would be beneficial to the core team.</p>
<p>The plugin search and installation process is another highly visible feature with a fresh new look. Check out the new <a href="http://wptavern.com/first-look-at-the-new-plugin-details-screen-coming-to-wordpress-4-0" target="_blank">plugin details modal</a> as well as the new grid view when searching for an extension.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/search-plugins.jpg" rel="prettyphoto[26019]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/search-plugins.jpg?resize=951%2C338" alt="search-plugins" class="aligncenter size-full wp-image-26091" /></a></p>
<p>You can help by testing the plugin modals and cards on as many screens and accessibility devices as possible in order to hunt down any bugs with the new display.</p>
<p>As this is a major release of WordPress, developers would do well to test their sites, themes and plugins against the beta while it&#8217;s still early. Hou-Sandí encourages anyone who has found a bug to post in the <a href="http://wordpress.org/support/forum/alphabeta" target="_blank">Alpha/Beta forum</a> or <a href="https://make.wordpress.org/core/reports/" target="_blank">file a ticket on trac</a>. The <a href="http://core.trac.wordpress.org/tickets/major" target="_blank">list of known bugs</a> will show you what testers have already identified so far. Some of those bugs may have already been <a href="http://core.trac.wordpress.org/query?status=closed&group=component&milestone=4.0" target="_blank">fixed</a>. Your bug reports and patches will help to make WordPress 4.0 shiny and polished when it&#8217;s officially released in August. Download Beta 1 from the <a href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/" target="_blank">release announcement</a> on WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 16:07:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Troy Dean: 101 Ways to Elevate Yourself and Demand Higher Fees";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36426";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://wordpress.tv/2014/07/10/troy-dean-101-ways-to-elevate-yourself-and-demand-higher-fees-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:696:"<div id="v-fi1ObGks-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36426/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36426/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36426&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/10/troy-dean-101-ways-to-elevate-yourself-and-demand-higher-fees-3/"><img alt="Troy Dean: 101 Ways to Elevate Yourself and Demand Higher Fees" src="http://videos.videopress.com/fi1ObGks/video-96bf3eaf39_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 15:56:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress.tv: Kyle Maurer: Shortcode Shenanigans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36330";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.tv/2014/07/10/kyle-maurer-shortcode-shenanigans/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:644:"<div id="v-ZgmKpbhK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36330/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36330/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36330&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/10/kyle-maurer-shortcode-shenanigans/"><img alt="Kyle Maurer: Shortcode Shenanigans" src="http://videos.videopress.com/ZgmKpbhK/video-60a7186e41_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 15:51:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Tammie Lister: The Theme Is In The Details";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36381";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.tv/2014/07/10/tammie-lister-the-theme-is-in-the-details/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:660:"<div id="v-cWkmumEQ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36381/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36381/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36381&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/10/tammie-lister-the-theme-is-in-the-details/"><img alt="Tammie Lister: The Theme Is In The Details" src="http://videos.videopress.com/cWkmumEQ/video-32fc4193a4_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 15:27:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Dev Blog: WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4016:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="http://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&group=component&milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: WP Engine Becomes The First Large Partner To Integrate Sidekick";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26052";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:190:"http://wptavern.com/wp-engine-becomes-the-first-large-partner-to-integrate-sidekick?utm_source=rss&utm_medium=rss&utm_campaign=wp-engine-becomes-the-first-large-partner-to-integrate-sidekick";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2152:"<div id="attachment_26073" class="wp-caption alignright"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WP-Engine-SIDEKICK-Portal.png" rel="prettyphoto[26052]"><img class="wp-image-26073 size-full" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WP-Engine-SIDEKICK-Portal.png?resize=296%2C457" alt="WP Engine User Portal" /></a><p class="wp-caption-text">WP Engine User Portal</p></div>
<p>WP Engine has <a title="http://wpengine.com/blog/#/2014/07/09/introducing-interactive-tutorials-within-user-portal/" href="http://wpengine.com/blog/#/2014/07/09/introducing-interactive-tutorials-within-user-portal/">revamped their user portal</a> and is the first large partner to integrate <a title="http://www.sidekick.pro/" href="http://www.sidekick.pro/">Sidekick</a> into its service. Sidekick provides WP Engine customers access to guided tours for understanding how different components of the User Portal work together. Sidekick is a product created by FlowPress to create interactive, narrated, guided walkthroughs. The new user portal has guides to learn about the WP Engine platform, managing your account, setting up your site, etc.</p>
<p>I was granted access to a WP Engine staging server to experience the benefits these guides offer and I&#8217;m impressed. They&#8217;re a helping hand at the click of a button. The walkthroughs are clear and to the point. Unlike reading tutorials or watching videos, it was nice to be guided through the process of managing my account.</p>
<p>The magic behind the walkthroughs is <a title="http://www.sidekick.pro/composer/" href="http://www.sidekick.pro/composer/">Sidekick Composer</a>. Although not available to the public yet, I consider it the Camtasia studio for WordPress. After watching a demo of what this plugin is capable of, I think plugin authors are going to love it. Instead of using pointers, they&#8217;ll be able to create interactive tours with narrated explanations on how to configure or use their plugin.</p>
<p>Keep an eye on the Tavern as rumor has it, the beta period for Sidekick Composer will open soon. When it happens, we&#8217;ll let you know.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 05:36:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: Create Your Own Custom Pointers in the WordPress Admin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26025";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/create-your-own-custom-pointers-in-the-wordpress-admin?utm_source=rss&utm_medium=rss&utm_campaign=create-your-own-custom-pointers-in-the-wordpress-admin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4358:"<p>Admin pointers were first added in <a href="http://codex.wordpress.org/Version_3.3" target="_blank">WordPress 3.3</a> for the purpose of helping users discover and navigate new features in major releases. For example, when widgets were added to the customizer, an admin pointer displayed to highlight live widget previews on the themes page.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/new-feature-admin-pointer.jpg" rel="prettyphoto[26025]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/new-feature-admin-pointer.jpg?resize=743%2C495" alt="new-feature-admin-pointer" class="aligncenter size-full wp-image-26034" /></a></p>
<p>The friendly pointers, when used sparingly, can draw attention to important items and help new users more effectively navigate the admin. Ordinarily, creating your own pointers requires a bit of custom coding. Fortunately, the admin pointers feature is easy to extend, so plugin developers have been able to harness it for unique uses.</p>
<p><a href="http://wordpress.org/plugins/better-admin-pointers/" target="_blank">Better Admin Pointers</a> is a plugin that makes it possible for anyone to create custom pointers and add them to any screen in the admin. The plugin saves the new pointers as a custom post type. Pointers will display until they are dismissed by the user.</p>
<p>Here&#8217;s an example of a pointer created to identify which plugin you&#8217;re editing:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-plugin.png" rel="prettyphoto[26025]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/edit-plugin.png?resize=1025%2C681" alt="edit-plugin" class="aligncenter size-full wp-image-26045" /></a></p>
<h3>Pointer Customization Options</h3>
<p>Better Admin Pointers allows you to customize every aspect of your custom pointers, including:</p>
<ul>
<li>Main content area</li>
<li>Pointer id &#8211; A unique id so that it can be tracked in the WP DB as dismissed</li>
<li>Screen &#8211; What page/screen it should appear on</li>
<li>Target &#8211; CSS id or class we want the pointer to attach to on the screen above</li>
<li>Position Edge &#8211; Which edge should be adjacent to the target? (left, right, top, or bottom)</li>
<li>Position Align &#8211; How should the pointer be aligned on this edge, relative to the target? (top, bottom, left, right, or middle)</li>
</ul>
<p>The plugin&#8217;s settings page has a checkbox option to &#8220;show current screen,&#8221; which will display the value you need for the screen ID when creating a new pointer.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/screen-id.jpg" rel="prettyphoto[26025]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/screen-id.jpg?resize=656%2C361" alt="screen-id" class="aligncenter size-full wp-image-26048" /></a></p>
<p>The WordPress Plugin API also has a handy <a href="http://codex.wordpress.org/Plugin_API/Admin_Screen_Reference" target="_blank">Admin Screen Reference</a> where you can easily locate IDs for the screens.</p>
<p><strong>A point of caution here:</strong> It&#8217;s easy to go overboard creating too many admin pointers. Some popular plugins annoy users to no end with their ever-present pointers. Don&#8217;t make this mistake if you decide to customize your own.</p>
<p>While testing the plugin, I was able to create and customize pointers faster than I imagined. The custom post type essentially guides you through the process with an explanation of the values expected in each box. For the average user, the most difficult aspect of customizing a pointer might be setting the target. If you&#8217;re not familiar with using your browser to inspect elements, it may be frustrating to determine the right CSS class or ID to use. However, the plugin&#8217;s most typical use case is most likely to be a developer setting up pointers for a client website or for someone who is new to WordPress.</p>
<p>I can see pointers being very useful for helping clients navigate custom features that a developer has built into the admin. <a href="http://wordpress.org/plugins/better-admin-pointers/" target="_blank">Better Admin Pointers</a> provides a quick way to write up a few friendly pointers to accompany new or confusing screens. Download it for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 23:03:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: First Look At The New Plugin Details Screen Coming To WordPress 4.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26010";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:198:"http://wptavern.com/first-look-at-the-new-plugin-details-screen-coming-to-wordpress-4-0?utm_source=rss&utm_medium=rss&utm_campaign=first-look-at-the-new-plugin-details-screen-coming-to-wordpress-4-0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2472:"<p>In the past two weeks, a lot of work has been done to improve the various plugin installer modals in the backend of WordPress. A <a title="http://en.wikipedia.org/wiki/Modal_window" href="http://en.wikipedia.org/wiki/Modal_window">modal</a> is a fancy way of saying a dialog or popup box. One of the modals revamped is the <a title="https://core.trac.wordpress.org/ticket/27440" href="https://core.trac.wordpress.org/ticket/27440">plugin details view</a>. When users click on the details link when searching for plugins to install from the backend of WordPress, a dialog box appears showing detailed plugin information. Here is what the current implementation looks like.</p>
<div id="attachment_26039" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelBefore.png" rel="prettyphoto[26010]"><img class="size-full wp-image-26039" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelBefore.png?resize=866%2C878" alt="Current Plugin Details Modal View" /></a><p class="wp-caption-text">Current Plugin Details Modal View</p></div>
<p>Here&#8217;s what the new view looks like. Keep in mind that it&#8217;s a work in progress.</p>
<div id="attachment_26043" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelAfter.png" rel="prettyphoto[26010]"><img class="size-full wp-image-26043" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPPluginInstallModelAfter.png?resize=837%2C852" alt="The Detailed Modal View For WordPress 4.0" /></a><p class="wp-caption-text">The Detailed Modal View For WordPress 4.0</p></div>
<p>As you can see, the plugin&#8217;s banner image is displayed at the top. A reviews tab has been added making it easy to read the latest reviews. In addition to the average rating, you can now see how the average is determined. All contributors to the plugin are listed along with their Gravatars. When the modal view shrinks, the detailed information is displayed above the description text.</p>
<p>I found the reviews hard to read in chronological order because it&#8217;s difficult to determine where a review begins and ends. Showing Gravatars is neat but I question their usefulness if they are the size of favicons. Overall, I like the improvements and can&#8217;t wait to see what the finished product looks like.</p>
<p><strong>What do you think of the new look?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 22:19:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Alex King: Custom Taxonomy as “Post Meta”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=14416";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://alexking.org/blog/2014/07/09/custom-taxonomy-as-post-meta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1135:"<p><em>I found this post while sorting through my old drafts and decided to go ahead and publish it rather than trashing it. Hopefully the code samples don&#8217;t break too badly in WordPress 3.9.</em></p>
<p>I&#8217;ve talked a bit about <a href="http://alexking.org/blog/2011/08/29/wordpress-post-meta-taxonomies">when to use custom taxonomies and when to use custom fields/post meta</a> (and how they can be used virtually interchangeably in some situations). If you want to use taxonomies, you&#8217;ll probably also want to:</p>
<ul>
<li>make sure that the terms you want to use exist in your custom taxonomy</li>
<li>limit the ability for these terms to be altered</li>
</ul>
<p>This Gist is a good start:</p>
<p><p>View the code on <a href="https://gist.github.com/3723819">Gist</a>.</p></p>
<p>You&#8217;ll probably also want to specify:</p>
<p><code>\'public\' =&gt; false,<br />
\'show_ui\' =&gt; true,</code></p>
<p>when defining your custom taxonomy. This makes the UI box for the taxonomy appear in the post/page editing interface as expected, but hides the admin forms for editing the taxonomy terms from the admin menu.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 21:33:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Matt: Pitchforks for Plutocrats";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43859";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://ma.tt/2014/07/pitchforks-for-plutocrats/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:322:"<p>Nick Hanauer advocates for $15 minimum wage in <a href="http://www.politico.com/magazine/story/2014/06/the-pitchforks-are-coming-for-us-plutocrats-108014.html">The Pitchforks Are Coming&#8230; For Us Plutocrats</a>. He was the first non-family investor in Amazon.com, and as he puts it, a &#8220;zillionaire.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 20:54:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: Kinsta Publishes Guide On The History Of WordPress, Its Ecosystem, and Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=26008";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:220:"http://wptavern.com/kinsta-publishes-guide-on-the-history-of-wordpress-its-ecosystem-and-community?utm_source=rss&utm_medium=rss&utm_campaign=kinsta-publishes-guide-on-the-history-of-wordpress-its-ecosystem-and-community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1316:"<p>Mark Gavalda, CEO of <a title="https://kinsta.com/" href="https://kinsta.com/">Kinsta WordPress Hosting</a>, has <a title="https://kinsta.com/learn/wordpress-history/" href="https://kinsta.com/learn/wordpress-history/">published an in-depth guide</a> covering the history of WordPress, its vast ecosystem, and the community surrounding it. Gavalda does a great job explaining the impact WordPress has had on so many individuals and businesses with quotes from notable members of the community.</p>
<p>The largest take away for me is that despite taking over an hour to read, it only scratches the surface. One of my favorite parts is a quote from Matt Mullenweg on contributing to WordPress.</p>
<blockquote><p>Just remember, every contribution counts, no matter what it looks like. It takes every one of us to make WordPress better.</p></blockquote>
<p>If you&#8217;d like to know more about the history of the project before it became WordPress, check out <a title="https://hakre.wordpress.com/2011/01/25/milestones-of-wordpress-early-project-timeline-ca-2000-to-2005/" href="https://hakre.wordpress.com/2011/01/25/milestones-of-wordpress-early-project-timeline-ca-2000-to-2005/">this list of milestones by Hakre</a>. His post covers the events in the 2000-2005 timeline that include the birth of WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 20:07:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WPTavern: WordPress.tv Adds Its First German Presentation: Konstantin Obenland on Underscores";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25985";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:228:"http://wptavern.com/wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-tv-adds-its-first-german-presentation-konstantin-obenland-on-underscores";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3139:"<p><a href="http://wordpress.tv/" target="_blank">WordPress.tv</a> added its first <a href="http://wordpress.tv/language/german/" target="_blank">German language video</a> today. Konstantin Obenland&#8217;s &#8220;<a href="http://wordpress.tv/2014/07/09/konstantin-obenland-underscores-ein-startertheme-fu%CC%88r-jeden/" target="_blank">Underscores: Ein Startertheme Für Alle</a>&#8221; presentation from WordCamp Hamburg is, surprisingly, the only German video to make it to WordPress.tv so far. Obenland is a code wrangler at Automattic and has also worked extensively with the default WordPress themes. His presentation covers the history and future of <a href="http://underscores.me/" target="_blank">Underscores</a> and its influence on theme development.</p>
<p></p>
<p>The <a href="http://de.slideshare.net/obenland/underscores-de" target="_blank">slides</a> for the presentation are also linked from its listing on WordPress.tv.</p>
<p>If you&#8217;re multilingual, one of the ways you can contribute to WordPress is by <a href="http://blog.wordpress.tv/2013/10/16/caption-and-subtitle/" target="_blank">captioning and subtitling videos</a>. Each video on WordPress.tv has a unique URL labeled &#8220;Subtitle this Video,&#8221; which lets you add subtitles in one of nine available languages. For example, if you click on Obenland&#8217;s video subtitles <a href="http://wordpress.tv/subtitle/?video=36369" target="_blank">link</a>, you&#8217;ll find the guided process for using the tools at <a href="http://www.amara.org/" target="_blank">amara.org</a> to add your subtitles. This is a little-known way that you can contribute to WordPress and help the community share its knowledge across languages.</p>
<p>WordPress.tv doesn&#8217;t appear to have an easy way to search for videos by language, as the search bar isn&#8217;t an effect way of narrowing them down. While guessing at the URLs, I found that WordPress.tv has 61 videos in <a href="http://wordpress.tv/language/japanese/" target="_blank">Japanese</a>, 56 in <a href="http://wordpress.tv/2014/06/20/tony-archambeau-accessibilite-wordpress-creer-des-sites-pour-tous-les-utilisateurs/" target="_blank">French</a>, 38 in <a href="http://wordpress.tv/language/spanish/" target="_blank">Spanish</a>, eight in <a href="http://wordpress.tv/language/russian/" target="_blank">Russian</a>, two in <a href="http://wordpress.tv/language/norwegian/" target="_blank">Norwegian</a>. There are likely many more languages represented there but they&#8217;re not easy to discover.</p>
<p>As the WordPress project is adding major <a href="http://wptavern.com/major-internationalization-improvements-planned-for-wordpress-4-0" target="_blank">internationalization improvements to the 4.0 release</a>, users who are new to the software will have an easier time getting on board. They will be in search for resources to help them get started and learn more. Right now, the vast majority of official WordPress learning resources are in English. In the future it will be exciting to see how the project adapts and changes to accommodate a growing international, multilingual community.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 18:09:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WordPress.tv: Konstantin Obenland: Underscores — Ein Startertheme für jeden";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36370";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://wordpress.tv/2014/07/09/konstantin-obenland-underscores-ein-startertheme-fu%cc%88r-jeden/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:700:"<div id="v-DnH1fCIN-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36370/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36370/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36370&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/09/konstantin-obenland-underscores-ein-startertheme-fu%cc%88r-jeden/"><img alt="Konstantin Obenland: Underscores — Ein Startertheme für jeden" src="http://videos.videopress.com/DnH1fCIN/video-e6cddbef07_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 15:20:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress.tv: Michele Butcher: Intro To Jetpack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36326";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.tv/2014/07/09/michele-butcher-intro-to-jetpack/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:642:"<div id="v-FPGL7Wlq-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36326/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36326/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36326&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/09/michele-butcher-intro-to-jetpack/"><img alt="Michele Butcher: Intro To Jetpack" src="http://videos.videopress.com/FPGL7Wlq/video-746566fa95_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 15:05:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"Post Status: Syed Balkhi and Thomas Griffin are joining forces";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6836";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:150:"http://www.poststat.us/syed-balkhi-thomas-griffin-awesome-motive/?utm_source=rss&utm_medium=rss&utm_campaign=syed-balkhi-thomas-griffin-awesome-motive";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5076:"<p><img class="aligncenter size-large wp-image-6842" src="http://www.poststat.us/wp-content/uploads/2014/07/syed-balkhi-thomas-griffin-awesome-motive-752x283.jpg" alt="syed-balkhi-thomas-griffin-awesome-motive" width="752" height="283" />Syed Balkhi and Thomas Griffin first partnered together when they created <a href="https://wordpress.org/plugins/floating-social-bar/">Floating Social Bar</a>, a free WordPress social sharing plugin. They decided to collaborate after meeting and getting along at WordCamp Raleigh.</p>
<p>From there, their relationship blossomed, and they decided to create a second product together. Syed specializes in marketing and business development, and Thomas specializes in development. Their second product was <a title="OptinMonster aims to be the dominant WordPress conversion plugin" href="http://www.poststat.us/optinmonster-wordpress-conversion-plugin/">OptinMonster</a>.</p>
<p>Both Syed and Thomas have successful WordPress-based businesses already. Syed&#8217;s company, <a href="http://awesomemotive.com/">Awesome Motive</a>, is behind the popular site <a href="http://wpbeginner.com">WP Beginner</a>, <a href="http://list25.com">List 25</a>, and more recently products like <a href="http://optinmonster.com">OptinMonster</a> and <a href="http://themelab.com">ThemeLab</a>. Thomas, through his company Griffin Media, is the creator of the popular <a href="http://soliloquywp.com/">Soliloquy</a> slider and <a href="http://enviragallery.com/">Envira Gallery</a> plugins.</p>
<p>Due to the success of OptinMonster, and their aligning views on business, ideals, and their complementary skillsets, the two have decided to merge their businesses. Thomas is now Awesome Motive&#8217;s Chief Technical Officer.</p>
<p>The deal was made in stock and cash. Awesome Motive operates as a management firm, and each project is its own entity. With Syed continuing on as President of Awesome Motive, and Thomas as CTO, they will now partner and collaborate across the spectrum of Awesome Motive projects.</p>
<p>Current active Awesome Motive projects are WP Beginner, List 25, ThemeLab, OptinMonster, Soliloquy, and Envira Gallery.</p>
<p>Since Syed and Thomas were already working together, it was a natural fit for the two to join across the board. Now Awesome Motive will benefit from Thomas&#8217; technical insight and expertise, and Thomas&#8217; projects will benefit from the network of products in the company, and Syed&#8217;s affiliate marketing and business help.</p>
<p>I talked to Syed and Thomas about the new relationship, which I&#8217;d encourage you to listen to. We talk about the structure of Awesome Motive, what&#8217;s coming down the pipeline, status of their current projects, and more.</p>
<p><!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href="http://s3.amazonaws.com/PostStatus/DraftPodcast/post-status-draft-thomas-griffin-syed-balkhi-awesome-motive.mp3">http://s3.amazonaws.com/PostStatus/DraftPodcast/post-status-draft-thomas-griffin-syed-balkhi-awesome-motive.mp3</a><br />
<a href="http://s3.amazonaws.com/PostStatus/DraftPodcast/post-status-draft-thomas-griffin-syed-balkhi-awesome-motive.mp3">Direct Download</a></p>
<h3>A partnership that makes sense</h3>
<p>I think this partnership makes sense. It seems like a good move to both parties, and it&#8217;s clear that Syed and Thomas enjoy working together.</p>
<p>With OptinMonster, ThemeLab, Soliloquy, and Envira Gallery under one roof, it makes for a pretty impressive commercial plugin portfolio &#8212; not to mention the website communities Syed has built in List 25 and WP Beginner. And of course, they have more up their sleeves that they are working on as we speak.</p>
<p>Awesome Motive was already probably larger than you would think before Thomas and his team joined, but now they are more than 15 people and enjoy multi-million dollar per year revenues.</p>
<p>I look forward to seeing how Awesome Motive further defines itself in the WordPress space. Syed and Thomas have both definitely left impressions individually, and I think together we&#8217;ll see a serious company and player in the WordPress product space further mature.</p>
<h3>Giving back</h3>
<p>Another thing I like about Syed and Awesome Motive is they like to give back. They currently <a href="http://www.wpbeginner.com/wpbeginner-5th-birthday-giveaway-help-build-a-school/">have a giveaway</a> going that&#8217;s aimed to raise money for <a href="http://fundraise.pencilsofpromise.org/fundraise?fcid=324942">Pencils of Promise</a> to build schools for kids in need in Guatemala.</p>
<p>They built one last year, this year they&#8217;re aiming to raise $50,000 to build two schools. You can donate and <a href="http://www.wpbeginner.com/wpbeginner-5th-birthday-giveaway-help-build-a-school/">enter the giveaway</a> to help.</p>
<hr />
<p>You can stay in touch with <a href="https://twitter.com/syedbalkhi">Syed</a> and <a href="https://twitter.com/jthomasgriffin">Thomas</a> on Twitter to learn more about this partnership as it unfolds.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jul 2014 05:55:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WordPress.tv: WordCamp Kansai 2014デザイナーが感じたGPLライセンスとWordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36117";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:199:"http://wordpress.tv/2014/07/08/wordcamp-kansai-2014%e3%83%87%e3%82%b6%e3%82%a4%e3%83%8a%e3%83%bc%e3%81%8c%e6%84%9f%e3%81%98%e3%81%9fgpl%e3%83%a9%e3%82%a4%e3%82%bb%e3%83%b3%e3%82%b9%e3%81%a8wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:759:"<div id="v-9vwIuA0H-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36117/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36117/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36117&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/08/wordcamp-kansai-2014%e3%83%87%e3%82%b6%e3%82%a4%e3%83%8a%e3%83%bc%e3%81%8c%e6%84%9f%e3%81%98%e3%81%9fgpl%e3%83%a9%e3%82%a4%e3%82%bb%e3%83%b3%e3%82%b9%e3%81%a8wordpress/"><img alt="ayakasumida.wmv" src="http://videos.videopress.com/9vwIuA0H/video-cbe243037d_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 22:23:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:118:"WPTavern: Proposed Customizer Improvements for WordPress 4.0 Land Amid Concerns Over Underlying Architectural Problems";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25913";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:280:"http://wptavern.com/proposed-customizer-improvements-for-wordpress-4-0-land-amid-concerns-over-underlying-architectural-problems?utm_source=rss&utm_medium=rss&utm_campaign=proposed-customizer-improvements-for-wordpress-4-0-land-amid-concerns-over-underlying-architectural-problems";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6579:"<div id="attachment_25972" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/hammer.jpg" rel="prettyphoto[25913]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/hammer.jpg?resize=742%2C316" alt="photo credit: beccaplusmolly - cc" class="size-full wp-image-25972" /></a><p class="wp-caption-text">photo credit: <a href="https://www.flickr.com/photos/beccaplusmolly/3054399737/">beccaplusmolly</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a></p></div>
<p>When widgets were <a href="http://wptavern.com/widget-customizer-approved-for-wordpress-3-9" target="_blank">added to the customizer</a> in 3.9, WordPress users were generally surprised and delighted. Live previews are so beneficial to the editing experience that contributors are starting to pursue an expansion of the role of the customizer into all aspects of WordPress.</p>
<p>Nick Halsey has been working extensively with the customizer as part of his <a href="http://make.wordpress.org/core/tag/menu-customizer" target="_blank">Google Summer of Code project</a> and recently published an <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/" target="_blank">update</a> detailing the planned improvements for the upcoming 4.0 release. The Appearance <a href="http://make.wordpress.org/core/components/" target="_blank">trac component</a> has now been renamed to Customize. Halsey&#8217;s clarifications of the terminology reveal where the project is heading in terms of prioritizing the customizer:</p>
<blockquote><p>We’re shifting toward using &#8216;Customizer&#8217; rather than &#8216;Theme Customizer&#8217;, as it isn’t necessarily theme-specific (though most of its uses currently are)&#8230;&#8217;Customize&#8217; could refer to anything. That’s the point; it could be used to customize any part of a site. The Customizer can be used for anything, and we’d like to encourage more experimentation with different uses of the Customizer.</p></blockquote>
<p>WordPress 4.0 will include a number of UI changes to the customizer along with a new <a href="https://core.trac.wordpress.org/ticket/27406" target="_blank">Panels API</a> that enables developers to group controls into sections.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/panels-ui.gif" rel="prettyphoto[25913]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/panels-ui.gif?resize=1025%2C579" alt="panels-ui" class="aligncenter size-full wp-image-25938" /></a></p>
<p>The proposed customizer changes for 4.0 provide <a href="https://core.trac.wordpress.org/ticket/28477" target="_blank">support for a wider array of controls</a> and parameters to help developers extend it for more varied uses beyond themes. <a href="https://core.trac.wordpress.org/ticket/27993" target="_blank">Contextual controls</a> are also on the list of proposed changes, which allow the controls to be visible or hidden based on the page the user is viewing.</p>
<h3>Is WordPress putting all its eggs in one basket with the customizer?</h3>
<p>Improvements to the customizer are expanding on all fronts. WordPress developers will soon be able to use it in many more ways after this iteration is complete. But are we putting a lot of effort into rapidly expanding a feature that may not be able to evolve as the web changes?</p>
<p>Matt Wiebe, design Engineer at Automattic, recently wrote a piece, enumerating some of the most critical issues in <a href="http://wp.mattwie.be/2014/06/27/evolving-the-customizer/" target="_blank">evolving the customizer</a> as it currently stands. His article highlights the difficulty of using the customizer on mobile devices, performance issues, a confusing UI and the fundamental limitations of its architecture:</p>
<blockquote><p>It’s also a JS-driven app wrapped around a PHP-only public API, which is I guess about what you’d expect from an early WP foray into something JS-driven. But this fundamental PHP dependency makes it basically impossible to account for a seamless switching of state while changing a previewed theme: a full page reload has to happen.</p></blockquote>
<p>Wiebe believes that some of the smaller issues he outlined can be addressed with core changes, but the underlying architectural issues may be impossible to address in a backwards-compatible manner. He is hopeful that eventually the customizer could make use of the upcoming WP API, though that would require a massive overhaul:</p>
<blockquote><p>Also, looking forward, the Customizer itself should be a client app of WP-API. Everything related to site appearance should be an API call away, rather than the tightly coupled thing that is the Customizer. This will open the door for, say, a native Customizer on Android or iOS or some other platform that doesn’t exist yet but will be important.</p></blockquote>
<p>The WP API is <a href="http://wptavern.com/json-rest-api-slated-for-wordpress-4-1-release" target="_blank">slated for inclusion in WordPress 4.1</a> which should arrive later this year. Meanwhile, development with the current customizer architecture charges forward.</p>
<p>Halsey briefly mentions a few of these issues in the conclusion of his <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/" target="_blank">proposal</a> under the &#8220;future work&#8221; section. He cites tickets that recognize <a href="https://core.trac.wordpress.org/ticket/28784" target="_blank">the customizer is not intuitive on mobile</a> and needs some help in terms of <a href="https://core.trac.wordpress.org/ticket/28580" target="_blank">performance</a>. Customizer-related <a href="https://core.trac.wordpress.org/query?status=!closed&component=Customize&milestone=Future+Release&desc=1&order=id" target="_blank">tickets</a> tagged for a future release address a few of the issues that can be improved with core changes.</p>
<p>It&#8217;s easy to nitpick problems with a relatively new feature in WordPress that hasn&#8217;t had time to develop. Many contributors have put a great deal of hard work into all of the upcoming improvements to the customizer. But the question here is whether or not this feature, with its current architecture, is a dead end until it is completely refactored to be able to provide users on all devices a better and more seamless editing experience. Are we sweeping too many concerns under the rug for future work? Or will the customizer be able to evolve and find a path forward through the roadblocks?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 22:10:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: In The Next Few Years, 90% Of WordPress Development Could Be JavaScript Based";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25916";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/in-the-next-few-years-90-of-wordpress-development-could-be-javascript-based?utm_source=rss&utm_medium=rss&utm_campaign=in-the-next-few-years-90-of-wordpress-development-could-be-javascript-based";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4898:"<p>In March of 2013, Matt Mullenweg <a title="http://memeburn.com/2013/03/in-the-future-we-will-only-need-five-computers-says-matt-mullenweg/" href="http://memeburn.com/2013/03/in-the-future-we-will-only-need-five-computers-says-matt-mullenweg/">stopped by the Memeburn office</a> to talk about how WordPress went from being just another blogging platform to becoming the CMS of choice for the majority of the web. The author of the article infers that Mullenweg thinks 90% of WordPress will be JavaScript based in the next few years.</p>
<blockquote><p>In the future, the platform will also feature a lot more JavaScript. In fact, he reckons that 90% of WordPress will be JavaScript-based within the next few years.</p></blockquote>
<p>When Eric Lewis recently asked Mullenweg on Twitter if he said the quote, his response clarified that he thinks the majority of PHP will be used for infrastructure such as updates, API&#8217;s, and the database layer. Meanwhile, user-facing improvements will be JavaScript driven. Most already are such as the editor, media, customizer and menus.</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/nacin">@nacin</a> <a href="https://twitter.com/ericandrewlewis">@ericandrewlewis</a> I\'d agree with <a href="https://twitter.com/nacin">@nacin</a> &#8211; 1/ Infrastructure stuff will likely remain majority PHP (updates, APIs, auth, DB layer)</p>
<p>&mdash; Matt Mullenweg (@photomatt) <a href="https://twitter.com/photomatt/statuses/475258697073979393">June 7, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/nacin">@nacin</a> <a href="https://twitter.com/ericandrewlewis">@ericandrewlewis</a> 2/ Most interesting user-facing improvements will be JS-driven, most already are. (editor, media, customizer, menus)</p>
<p>&mdash; Matt Mullenweg (@photomatt) <a href="https://twitter.com/photomatt/statuses/475259028465917953">June 7, 2014</a></p></blockquote>
<p></p>
<p>Spurred on by the discussion, <a href="http://neliosoftware.com/javascript-taking-wordpress/">Jordi Cabot of NelioSoftware.com</a> dove into the WordPress source code. Using graphs, Cabot shows how many JavaScript files and lines of code have been added to WordPress since 0.7 was released. He then compares the number of PHP and JavaScript lines within the source code.</p>
<div id="attachment_25931" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/PHPvsJavascriptInWordPressCodeOverTime.png" rel="prettyphoto[25916]"><img class="size-full wp-image-25931" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/PHPvsJavascriptInWordPressCodeOverTime.png?resize=832%2C613" alt="PHP vs JavaScript Lines Of Code in WordPress" /></a><p class="wp-caption-text">Image Courtesy of <a title="http://neliosoftware.com/javascript-taking-wordpress/" href="http://neliosoftware.com/javascript-taking-wordpress/">Nelio.com</a></p></div>
<p>The numbers show that JavaScript is only 16.6% of the total source code of WordPress with PHP representing 83.4%. So while JavaScript isn&#8217;t taking over WordPress development any time soon, it&#8217;s definitely a valuable skill worth knowing.</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/photomatt">@photomatt</a> <a href="https://twitter.com/nacin">@nacin</a> <a href="https://twitter.com/ericandrewlewis">@ericandrewlewis</a> Amazing how the web has gone from "just say no to javascript!" &#8211; to &#8211; "we need more javascript!"</p>
<p>&mdash; Greg Rickaby (@GregRickaby) <a href="https://twitter.com/GregRickaby/statuses/475266879758811136">June 7, 2014</a></p></blockquote>
<p></p>
<p>Like Greg Rickaby, I find it fascinating that JavaScript has seen a resurgence. At one point, JavaScript seemed to be one of those poisonous things on the web that caused nothing but problems for browsers.</p>
<p>I think various libraries like <a title="http://mootools.net/" href="http://mootools.net/">MooTools</a>, <a title="http://jquery.com/" href="http://jquery.com/">jQuery</a>, and <a title="http://nodejs.org/" href="http://nodejs.org/">Node.js</a> are largely responsible for the renewed interest in the language. I also think the <a title="http://en.wikipedia.org/wiki/Ajax_%28programming%29" href="http://en.wikipedia.org/wiki/Ajax_%28programming%29">introduction of Ajax</a> played a role as well, going back to 2004 when Google used it for Gmail and then Google Maps. Neil Taylor of Myplanet.io <a title="http://myplanet.io/article/a-brief-history-of-javascript/" href="http://myplanet.io/article/a-brief-history-of-javascript/">has a great article</a> covering the brief history of the JavaScript language.</p>
<p>What factors can you come up with that explain the renewed interest in JavaScript? What advice would you give people wanting to learn JavaScript?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 21:59:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Matt: WSJ Turns 125 &amp; Future of Management";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43864";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://ma.tt/2014/07/wsj-turns-125-future-of-management/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1435:"<p>The <a href="http://online.wsj.com/public/page/WSJ-125-Anniversary.html">Wall Street Journal has a nice feature on their 125th anniversary</a> that includes thoughts from people from <a href="http://online.wsj.com/articles/alice-waters-says-the-future-of-food-is-sustainable-and-locally-sourced-1404763421">Alice Waters</a> to <a href="http://online.wsj.com/articles/tyra-banks-says-beauty-in-the-future-will-mean-looking-different-1404762610">Tyra Banks</a> and everyone in between, including <a href="http://online.wsj.com/articles/matt-mullenweg-on-the-future-of-managers-trustand-verify-1404763642">yours truly on the Future of Managers</a>. Here&#8217;s my quote:</p>
<blockquote><p>The factory model of work is dead, but its vestiges still haunt modern-day information workers from the giant companies all the way down to startups and bosses who blindly follow models of how things have been done before rather than reimagining how we work.</p>
<p>It should not matter what hours you work or where you&#8217;re [working] from. What matters is how you communicate and what you get done. It&#8217;s a waste of the natural resources of time and energy to commute; when we break the shackles of what looks like work versus what actually drives value, 90% of the cost and space of an office and management will disappear. We will manage by trust and measuring output, rather than the easier task of tallying input.</p></blockquote>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 21:46:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WordPress.tv: Dorthe Sode Stengade Sønderskov: WordPress – fra Blog til Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36170";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://wordpress.tv/2014/07/08/dorthe-sode-stengade-sonderskov-wordpress-fra-blog-til-business/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:721:"<div id="v-J8S17zBG-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36170/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36170/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36170&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/08/dorthe-sode-stengade-sonderskov-wordpress-fra-blog-til-business/"><img alt="Dorthe Sode Stengade Sønderskov: WordPress – fra Blog til Business" src="http://videos.videopress.com/J8S17zBG/fra-blog-til-business-lille1_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 19:09:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WordPress.tv: René Frederiksen: From blogger to authority – content, earnings, and technique";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36173";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wordpress.tv/2014/07/08/rene-frederiksen-from-blogger-to-authority-content-earnings-and-technique/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:739:"<div id="v-S1pmZPnK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36173/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36173/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36173&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/08/rene-frederiksen-from-blogger-to-authority-content-earnings-and-technique/"><img alt="René Frederiksen: From blogger to autority – content, earnings, and technique" src="http://videos.videopress.com/S1pmZPnK/from-blogger-to-authority_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 19:09:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Post Status: Automating i18n in WordPress themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6825";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:132:"http://www.poststat.us/automating-i18n-wordpress-themes/?utm_source=rss&utm_medium=rss&utm_campaign=automating-i18n-wordpress-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11460:"<p><img class="aligncenter size-large wp-image-6830" src="http://www.poststat.us/wp-content/uploads/2014/07/i18n-wordpress-automation-752x300.jpg" alt="i18n-wordpress-automation" width="752" height="300" />According to the Polygots Make blog, WordPress is used all over the world and in many different languages. To put that in perspective, more than a third of existing WordPress installations are non-English and in his keynote at WordCamp Seattle, core developer Andrew Nacin mentioned that only 5-10% of the world speaks English.</p>
<p>At <a href="http://audiotheme.com/">AudioTheme</a>, we&#8217;ve been selling themes for a little more than a year and have already had sales in at least 45 countries, with only around 52% of total sales coming from customers in the United States.</p>
<p>It doesn&#8217;t take a math degree to know there&#8217;s a huge opportunity for growth.</p>
<p>WordPress itself has rich language capabilities and the core developers are continuously improving the experience for non-English users. <a href="http://make.wordpress.org/core/2014/05/21/internationalization-goals-for-4-0/">With a major push in 4.0</a>, and continuing through the end of the year, it&#8217;ll become easier than ever to use WordPress in other languages.</p>
<p>As a developer, it only makes sense to prepare your themes and plugins for use in other languages &#8212; a process called internationalization (i18n). In his <a href="http://www.poststat.us/understand-wordpress-internationalization-translation/">primer on i18n and localization</a> (l10n), Brian Krogsgard concluded by saying:</p>
<blockquote><p>It’s time for us to stop ignoring other languages. Internationalization isn’t a feature. If you don’t have properly [internationalized] plugins and themes, you have bugs in your project. That’s all there is to it.</p></blockquote>
<p>Needless to say, it can be a <a href="http://zedejose.com/woo-you-too-have-woes/">frustrating experience</a> when WordPress plugins and themes are difficult to work with in other languages because they&#8217;re not properly internationalized, but too often, i18n really is an afterthought. Part of that comes down to confusion about what&#8217;s involved and it&#8217;s partly due to the tedium of setting up and maintaining the tools and environment.</p>
<p>Fortunately, it&#8217;s fairly easy to implement i18n and there are tools that can help automate some of the mundane aspects.</p>
<h3>i18n Basics</h3>
<p>For the most part, preparing a theme consists of a few basic steps:</p>
<ul>
<li>Internationalize strings with <a href="http://make.wordpress.org/docs/theme-developer-handbook/part-two-theme-functionality/internationalization/#localization-functions">gettext function calls</a> during development</li>
<li><a href="http://codex.wordpress.org/I18n_for_WordPress_Developers#Text_Domains">Add &#8220;Text Domain&#8221; and &#8220;Domain Path&#8221; headers</a></li>
<li>Load the language file with a call to <a href="http://codex.wordpress.org/Function_Reference/load_theme_textdomain"><code>load_theme_textdomain()</code></a></li>
<li>Create an <a href="https://codex.wordpress.org/Right-to-Left_Language_Support">RTL style sheet</a></li>
<li>Generate and include a POT file</li>
</ul>
<p>There is a plethora of resources about getting your projects up to snuff, but <a href="http://zedejose.com/dear-wp-job-manager-need-talk/">i18n is also an ongoing process</a>. Those last two items, in particular, may require continued maintenance.</p>
<p>I&#8217;m a big fan of automating workflows to save time; reduce the tedium of repeatable tasks; maintain consistency between team members, operating systems, and tools; and improve quality. At AudioTheme, we&#8217;ve worked hard to refine our processes, build tools, and make our products accessible to international audiences, so I&#8217;d like to introduce a couple of the tools and methods we&#8217;ve built and use to create POT files, generate RTL style sheets and enqueue them.</p>
<h3>Generating POT Files</h3>
<p>WordPress has a fairly robust suite of PHP tools for handling all sorts of internationalization tasks, namely generating POT files, but they were somewhat hidden before being incorporated into the core development branch in 3.6. Even so, they&#8217;re still awkward to use with plugins and themes and require external dependencies like gettext, which can be hard to install on some systems. Getting everyone on a team properly set up and using them consistently can be quite the hassle.</p>
<p>That&#8217;s where <a href="https://github.com/blazersix/grunt-wp-i18n">grunt-wp-i18n</a> helps out. It&#8217;s essentially a Grunt plugin wrapper for the PHP-based tools, which is important because they handle some WordPress-specific things like package headers, translator comments and page template names.</p>
<p>We&#8217;ve been able to remove many of the dependencies required by the PHP tools, so if you&#8217;re already using Grunt, you&#8217;re all set &#8212; not even WordPress is needed. The Grunt plugin also provides much more control over the data that ends up in the POT file, allowing you to make it even easier for users to localize their themes using tools like Poedit.</p>
<p>Once a project is configured, the POT file can be regenerated every time a new version is released.</p>
<p>It&#8217;s already been adopted by plugins like Jetpack, bbPress, BuddyPress and WordPress SEO by Yoast, amongst others. Here&#8217;s a Gist demonstrating how to <a href="https://gist.github.com/bradyvercher/3868b1c90d7bf404016d">incorporate it into your project</a>.<span id="more-6825"></span></p>
<a href="https://gist.github.com/3868b1c90d7bf404016d" target="_blank"><em>View this code snippet on GitHub.</em></a>
<p>Wait, that&#8217;s it? Yep, the Grunt plugin automatically reads the text domain and other settings from the theme&#8217;s headers if they exist, otherwise your set up might require a few more settings. Run <code>grunt makepot</code> and you&#8217;ll have a new POT file.</p>
<h3>RTL Style Sheets</h3>
<p>Right-to-left (RTL) language support is largely neglected in most themes. Underscores &#8212; a fantastic starter theme &#8212; advocates creating an <code>rtl.css</code> style sheet with RTL-specific rules to override default left-to-right rules. While that&#8217;s better than nothing, the downsides are that it&#8217;s a manual process prone to errors and requires RTL sites to load two style sheets.</p>
<p>After adopting Grunt, WordPress core implemented a task to automate the generation of RTL style sheets using CSSJanus and they haven&#8217;t committed any RTL-related CSS patches since last year.</p>
<blockquote class="twitter-tweet" width="550"><p>No RTL-specific patches to WordPress since last year thanks to cssjanus. <a href="https://twitter.com/aaronjorbin">@aaronjorbin</a> <a href="https://twitter.com/hashtag/osb14?src=hash">#osb14</a></p>
<p>&mdash; Mel Choyce (@melchoyce) <a href="https://twitter.com/melchoyce/statuses/482225474811076608">June 26, 2014</a></p></blockquote>
<p></p>
<p>Why not take advantage of the same tools?</p>
<p>CSSJanus converts LTR properties and values in a style sheet to RTL. The project page says it may not always be enough, but it&#8217;s a start. We can use the same <a href="https://github.com/yoavf/grunt-cssjanus">grunt-cssjanus</a> plugin created by Yoav Farhi that&#8217;s used in core.</p>
<p>As I mentioned, <code>rtl.css</code> is loaded <em>in addition to</em> the main style sheet, so automatically generating it with CSSJanus would mean we&#8217;re duplicating every rule in <code>style.css</code> and overriding them in <code>rtl.css</code>. Needless to say, that&#8217;s even worse for performance.</p>
<p>Instead, we can make the CSSJanus Grunt task save the file as <code>style-rtl.css</code>, which has the added benefit of grouping the files by name and further clarifying what the new file does.</p>
<a href="https://gist.github.com/3868b1c90d7bf404016d" target="_blank"><em>View this code snippet on GitHub.</em></a>
<h3>There Can Be Only One</h3>
<p>If you&#8217;re not familiar with how <code>rtl.css</code> is enqueued, WordPress automatically loads various style sheets if they exist (rtl.css, ltr.css, {locale}.css, etc.), but <code>style-rtl.css</code> isn&#8217;t one of those. So how do we enqueue it instead of the default style sheet without resorting to complicated hacks?</p>
<p>Again, we can turn to core for the solution: Use <code>WP_Dependency::add_data()</code> by way of the <code>wp_style_add_data()</code> function added in 3.6. It has a few use cases, but in our situation, we want to specify an RTL style sheet that should <em>replace</em> the default style sheet. After enqueueing the main style sheet as usual, make a call to it like this:</p>
<a href="https://gist.github.com/3868b1c90d7bf404016d" target="_blank"><em>View this code snippet on GitHub.</em></a>
<p>That lets WordPress know we want to replace <code>style.css</code> with <code>style-rtl.css</code> for RTL languages.</p>
<p><a href="https://github.com/Automattic/_s/blob/master/rtl.css">Underscores&#8217; RTL style sheet</a> contains a default CSS rule for setting the text direction on the <code>body</code> element, so we&#8217;ll want to add that to <code>style.css</code> like this:</p>
<a href="https://gist.github.com/3868b1c90d7bf404016d" target="_blank"><em>View this code snippet on GitHub.</em></a>
<p>The <code>@noflip</code> comment tells CSSJanus not to convert that rule and the <code>.rtl</code> class ensures it&#8217;s only applied when an RTL language is loaded.</p>
<p>That&#8217;s really all there is to it. We now have:</p>
<ul>
<li>An automatically generated RTL style sheet</li>
<li>That&#8217;s grouped with <code>style.css</code> for better organization and improved clarity</li>
<li>Only one style sheet being enqueued for RTL support</li>
</ul>
<h3>Wrapping Up</h3>
<p>Compared to the time it takes to develop a theme, i18n is quick and easy, so don&#8217;t limit the theme&#8217;s potential to English speakers and don&#8217;t let Brian call your code buggy.</p>
<p>I focused on themes in this article, but a similar setup is possible for plugins and even the editor style sheet in themes. It just requires a little more configuration in the Grunt tasks.</p>
<p>There are plenty of other possibilities for automating tasks with Grunt, from injecting text domains during the build process to managing translations with a service like <a href="https://www.transifex.com/">Transifex</a> &#8212; let us know what cool things you&#8217;re doing with i18n and l10n in your WordPress projects.</p>
<div id="single-hcard-bradyvercher" class="loop-meta vcard"><h4 class="author-bio fn n">Brady Vercher</h4><div class="author-description"><img alt="Brady Vercher" src="http://1.gravatar.com/avatar/f50430f1bff5c24098fe94b48e8ff320?s=150&d=http%3A%2F%2F1.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D150&r=G" class="avatar avatar-150 photo" height="150" width="150" /><div class="user-bio author-bio">Brady Vercher is a WordPress developer, and is a co-founder of <a href="http://www.blazersix.com/">BlazerSix</a> and <a href="http://audiotheme.com">AudioTheme</a>. Brady enjoys the outdoors, but works at a desk. Go figure. Follow Brady on Twitter <a href="https://twitter.com/bradyvercher">@bradyvercher</a></div><!-- .user-bio .author-bio --></div><!-- .loop-description --></div><!-- .loop-meta -->";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 17:53:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Brady Vercher";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: WordPress Feature Plugin Planned to Improve Image Editing Experience";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25878";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:200:"http://wptavern.com/wordpress-feature-plugin-planned-to-improve-image-editing-experience?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-feature-plugin-planned-to-improve-image-editing-experience";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3327:"<p>Some of the best collaborations and discussions happen at WordCamps. While attending the WordCamp Seattle contributor day last month, Siobhan McKeown, Mike Schroder, Morten Rand-Hendriksen, and Sonja Leix began some preliminary discussions on how they could improve the image editing experience in WordPress.</p>
<p>The current state of WordPress image editing is functional with basic rotation and cropping features, but it&#8217;s also confusing and frustrating. McKeown and collaborators are <a href="http://make.wordpress.org/ui/2014/07/07/feature-plugin-improving-image-editing/" target="_blank">proposing</a> an image editing feature plugin to improve the experience.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/wordpress-image-editing.jpg" rel="prettyphoto[25878]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/wordpress-image-editing.jpg?resize=906%2C351" alt="wordpress-image-editing" class="aligncenter size-full wp-image-25895" /></a></p>
<p>The team isn&#8217;t trying to reinvent the wheel when it comes to image editing. <strong>&#8220;WordPress is not an image editing platform,&#8221;</strong> McKeown said. <strong>&#8220;But we do offer some minimal image editing tools and, since they’re there, they should be intuitive instead of anger inducing.&#8221;</strong> After identifying the major pain points with WordPress image editing, the team hopes that the feature plugin will provide the following:</p>
<ul>
<li>A set of simple image editing tools that just work (crop, rotate, scale)</li>
<li>Image editing tools that integrate better with image uploading workflows</li>
<li>Image editing tools that are easy to access</li>
<li>An interface that is extensible so that plugin developers can create advanced image editing which can be easy integrated</li>
</ul>
<p>The team will be conducting interviews with various user types, especially those who author image-heavy WordPress blogs, such as food bloggers, photobloggers, tutorial writers, etc. They are also setting out to examine how other platforms provide image editing. From there they will move on to UI mockups, design, coding and testing.</p>
<p>The project is still in the planning stages and anyone who wants to be involved is welcome. The team is looking for people to conduct user interviews, research other platforms, provide screenshots, mockup workflows and UI, provide feedback, and code the plugin. Backbone skills are especially welcome.</p>
<p>Contributors working to improve the image editing experience will have a major impact on millions of WordPress users. Many trac <a href="https://core.trac.wordpress.org/ticket/27664" target="_blank">tickets</a> have been <a href="https://core.trac.wordpress.org/ticket/21810" target="_blank">logged</a> <a href="https://core.trac.wordpress.org/ticket/28038" target="_blank">concerning</a> the <a href="https://core.trac.wordpress.org/ticket/27664" target="_blank">image editor</a> and core contributors agree that it&#8217;s time for a new approach. If you&#8217;re frustrated by the current image editing tools, you can help this project gain momentum by getting the word out and volunteering to help on <a href="http://make.wordpress.org/ui/2014/07/07/feature-plugin-improving-image-editing/" target="_blank">make.wordpress.org</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 17:21:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WPTavern: WPBeginner Turns 5, Celebrates With Campaign To Build Two New Schools In Guatemala";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25881";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:226:"http://wptavern.com/wpbeginner-turns-5-celebrates-with-campaign-to-build-two-new-schools-in-guatemala?utm_source=rss&utm_medium=rss&utm_campaign=wpbeginner-turns-5-celebrates-with-campaign-to-build-two-new-schools-in-guatemala";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4420:"<p>WordPress resource site <a title="http://www.wpbeginner.com/" href="http://www.wpbeginner.com/">WPBeginner</a>, is celebrating its fifth birthday. As part of the celebration, it&#8217;s <a title="http://www.wpbeginner.com/wpbeginner-5th-birthday-giveaway-help-build-a-school/" href="http://www.wpbeginner.com/wpbeginner-5th-birthday-giveaway-help-build-a-school/">giving away</a> $26K worth of prizes. Prizes range from licenses to popular WordPress plugins such as Backup Buddy and Soliloquy to webhosting packages with Pantheon and SiteGround. However, it&#8217;s not just about giving away prizes, Syed Balhki wants to help build two new schools in Guatemala.</p>
<p>Last year, <a title="http://fundraise.pencilsofpromise.org/fundraise?fcid=249743" href="http://fundraise.pencilsofpromise.org/fundraise?fcid=249743">Balhki and those who donated</a> helped build a brand new school building with 12 classrooms with $25K. According to the project&#8217;s description, it only takes $25 per year to educate a child. Photos of the WPBeginner staff interacting with the children at the location of their new school building are available on the <a title="http://fundraise.pencilsofpromise.org/fundraise?fcid=324942" href="http://fundraise.pencilsofpromise.org/fundraise?fcid=324942">project page</a>.</p>
<div id="attachment_25885" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPBeginnerBuildsNewSchoolINGuatemala.jpg" rel="prettyphoto[25881]"><img class="size-full wp-image-25885" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/WPBeginnerBuildsNewSchoolINGuatemala.jpg?resize=600%2C400" alt="WPBeginner Helps Open New School Building In Guatemala" /></a><p class="wp-caption-text">WPBeginner Helps Open New School Building In Guatemala</p></div>
<p>The campaign is part of the <a title="http://pencilsofpromise.org/" href="http://pencilsofpromise.org/">Pencils of Promise</a> charity. Pencils of Promise is a for purpose organization that builds schools, trains teachers, and funds scholarships. According to the Pencils of Promise website, a <em>for purpose organization</em> is defined as &#8220;blending the head of a for-profit business with the heart of a humanitarian nonprofit.&#8221; The entirety of online donations go to PoP programs. To date, the organization has built <strong>224 schools</strong> with <strong>28,310 students served</strong>, and <strong>15M education hours</strong> delivered.</p>
<h3>How To Earn Entries</h3>
<p>To enter the giveaway, simply provide your email address or login using Facebook. The email address is used as the primary means of contact if you win. If you&#8217;re not sure about the details of the giveaway, read the Terms and Conditions at the bottom of the form. After filling in your details, you&#8217;ll be given the option to Tweet the giveaway and follow WPBeginner on Twitter. Each action gives you an extra five entries. <a title="http://fundraise.pencilsofpromise.org/fundraise?fcid=324942" href="http://fundraise.pencilsofpromise.org/fundraise?fcid=324942">Donating $25 to the cause</a> will also earn you bonus entries.</p>
<p>&nbsp;</p>
<div id="attachment_25884" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/EnterWPBeginnerGiveaway.png" rel="prettyphoto[25881]"><img class="size-full wp-image-25884" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/EnterWPBeginnerGiveaway.png?resize=422%2C738" alt="Multiple Ways To Earn Entries" /></a><p class="wp-caption-text">Multiple Ways To Earn Entries</p></div>
<p>Balkhi&#8217;s fundraising goal is $50K. At the time of publishing, <strong>$38,134</strong> has been raised with 40 donations. While the names of donators are not explicitly public, those who have chosen to share their amounts and names are available in the comments of the project page. Several WordPress companies have jumped on board to show their support for the cause by either becoming a Platinum, Gold, or Silver sponsor. Those sponsors have donated $5K, $1K, and $500 respectively.</p>
<p>The donation amount is not set in stone at $25. You can donate any amount you&#8217;re comfortable with. If you can afford it, consider giving to this noble cause. It&#8217;s a win-win situation for donators. You get to help build a school in Guatemala while putting yourself in the running to win some cool prizes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Jul 2014 00:29:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: How to Create a Portfolio in WordPress Using Dribbble Shots";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25844";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/how-to-create-a-portfolio-in-wordpress-using-dribbble-shots?utm_source=rss&utm_medium=rss&utm_campaign=how-to-create-a-portfolio-in-wordpress-using-dribbble-shots";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4722:"<p><a href="https://dribbble.com/" target="_blank">Dribbble</a> was founded as a community for designers in 2009 and has since grown to become a profitable company and a popular source for inspiration on the web. The site provides a social outlet for designers, allowing members to share samples of their work and get feedback from other professionals and enthusiasts.</p>
<p>While you may have a large collection of shots on Dribbble, it&#8217;s no replacement for hosting a portfolio on your own domain.  WordPress users who want to create a portfolio using their Dribbble shots are in luck. There are three free plugins on WordPress.org that make it easy to display your shots as a portfolio on your site.</p>
<h2>Dribbble Portfolio Shots</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/dribbble-portfolio-shots.jpg" rel="prettyphoto[25844]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/dribbble-portfolio-shots.jpg?resize=772%2C250" alt="dribbble-portfolio-shots" class="aligncenter size-full wp-image-25854" /></a></p>
<p><a href="http://wordpress.org/plugins/dribbble-portfolio-shots/" target="_blank">Dribbble Portfolio Shots</a> is simple plugin that lets you share your shots via a shortcode. The output is responsive and arranges shots in a 2-column, 4-column, or 6-column grid.</p>
<p>Shots can be displayed on any post or page using a shortcode, which can be customized for the number of columns you want to include:</p>
<p><code>[dribbble_shots id="YOUR_DRIBBBLE_NAME" column=2]</code></p>
<p>The displayed shots link directly to their sources on Dribbble. Check out a <a href="http://ramit-designs.com/wordpress/?p=1" target="_blank">live demo</a> to see the Dribbble Portfolio shots plugin in action.</p>
<h2>Dribbble Portfolio</h2>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/dribbble-portfolio.png" rel="prettyphoto[25844]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/dribbble-portfolio.png?resize=772%2C250" alt="dribbble-portfolio" class="aligncenter size-full wp-image-25850" /></a></p>
<p>The <a href="http://wordpress.org/plugins/dribbble-portfolio/" target="_blank">Dribbble Portfolio</a> plugin also uses a shortcode to display shots, but it has a few more advanced options. The shortcode will display up to 15 shots and includes parameters that allow you to customize the border color, background color, and shots count.</p>
<p><code>[deribble_shots userid="usename" bgcolor="#fff" border_color="#e8e8e8" count="12" ]</code></p>
<p>Clicking on shots will display them in a popup, instead of linking to Dribbble. Each shot displays the title and counts for views, comments, and likes.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/example-dribbble-portfolio.png" rel="prettyphoto[25844]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/example-dribbble-portfolio.png?resize=982%2C1245" alt="example-dribbble-portfolio" class="aligncenter size-full wp-image-25864" /></a></p>
<p>View a <a href="http://kentothemes.com/demo/dribbble-portfolio/" target="_blank">live demo</a> of Dribbble Portfolio to preview the plugin&#8217;s output. You&#8217;ll find that it&#8217;s responsive and displays the user&#8217;s Dribbble avatar at the top.</p>
<h2>Highlight Reel</h2>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/highlight-reel.png" rel="prettyphoto[25844]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/highlight-reel.png?resize=772%2C250" alt="highlight-reel" class="aligncenter size-full wp-image-25856" /></a></p>
<p>The <a href="http://wordpress.org/plugins/highlight-reel/" target="_blank">Highlight Reel</a> displays your recent Dribbble shots using a shortcode or template tag. After activating the plugin, you&#8217;ll be prompted to enter your username on the settings page. Unlike the Dribbble Portfolio plugin, there are no limitations on the number of shots that can be displayed.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/highlight-reel-settings.jpg" rel="prettyphoto[25844]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/highlight-reel-settings.jpg?resize=580%2C298" alt="highlight-reel-settings" class="aligncenter size-full wp-image-25868" /></a></p>
<p>With the help of a plugin, you can continue to use Dribbble to share your creations and have them automatically update on your WordPress site. All of these plugins enable heavy Dribbble users to keep their portfolios updated without any additional effort. You can continue to promote yourself and get discovered on Dribbble while maintaining a portfolio on your own domain with WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 07 Jul 2014 21:36:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"Post Status: The state of handling custom metadata in WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6809";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:148:"http://www.poststat.us/state-handling-custom-metadata-wordpress/?utm_source=rss&utm_medium=rss&utm_campaign=state-handling-custom-metadata-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:10541:"<p><img class="aligncenter size-large wp-image-6820" src="http://www.poststat.us/wp-content/uploads/2014/07/metadata-wordpress-752x300.jpg" alt="metadata-wordpress" width="752" height="300" />WordPress has a table for handling <a href="http://codex.wordpress.org/Metadata_API">metadata</a> of posts. Quite simply, it&#8217;s a good place to store &#8220;stuff&#8221; that relates to a post, but doesn&#8217;t belong in one of the standard parts of the posts table.</p>
<p>Metadata can be nearly anything. And it can be displayed however a theme wants to display it. You can grab it all and list it out together (as was a common use case for WordPress&#8217; early blog structures). Or you can control what metadata goes where, very specifically.</p>
<h3>Using custom metadata gets us out of the_content()</h3>
<p>Today, metadata is used by plugins and themes that are distributed, and very often by developers creating custom things on WordPress.</p>
<p>Here&#8217;s a sample list of metadata attached to one of my posts:</p>
<p><img class="aligncenter size-large wp-image-6811" src="http://www.poststat.us/wp-content/uploads/2014/07/custom-meta-data-752x292.gif" alt="custom-meta-data" width="752" height="292" /></p>
<p>But it can get much more complicated than that. Take an eCommerce site, for instance. If a product is a custom post type, then the price, shipping details, dimensions, and many more things could all be metadata stored for that product.</p>
<p>Custom meta boxes and custom meta field interfaces allow us to structure these things nicely in the WordPress admin.</p>
<p><img class="aligncenter size-large wp-image-6813" src="http://www.poststat.us/wp-content/uploads/2014/07/custom-meta-b0x-752x431.png" alt="custom-meta-b0x" width="752" height="431" /></p>
<p>Then, on the front end of the website, you have control over how to grab and utilize that data. For example, the metabox shown above enables the use of that data on a page like this:</p>
<p><img class="aligncenter size-large wp-image-6814" src="http://www.poststat.us/wp-content/uploads/2014/07/meta-data-in-action-752x499.png" alt="meta-data-in-action" width="752" height="499" /></p>
<h3>Metadata UI interfaces are fractured</h3>
<p>Much of what I&#8217;m saying is old news to you. I get that. You know, use, and love making creative use of post metadata in WordPress. However, what I&#8217;m sure you also know, is that the landscape of tools for creating interfaces for entering custom metadata is incredibly fractured.</p>
<p>There are dozens (if not hundreds) of publicly available plugins, drop-in classes, and generators for creating custom metaboxes and interfaces for inputting metadata. Here&#8217;s a screenshot of an incredible breakdown of various available tools.</p>
<p><img class="aligncenter size-large wp-image-6812" src="http://www.poststat.us/wp-content/uploads/2014/07/wp-custom-fields-meta-plugins-752x345.gif" alt="wp-custom-fields-meta-plugins" width="752" height="345" /></p>
<p>This screenshot is from <a href="https://docs.google.com/spreadsheet/ccc?key=0AoY8IFUX301qdFhBaERLUEUwa3U0YjFYTnBmaU1mbmc&usp=drive_web#gid=3">Scott Kingsley Clark&#8217;s comparison table</a>. If it&#8217;s overwhelming to you, that&#8217;s my point.</p>
<p>WordPress&#8217; core metadata / custom fields interface is lacking. So tools have come about to make making custom meta boxes, defining fields, and interfacing with custom metadata easier.</p>
<h3>Problems arise from non-standard meta handling</h3>
<p>Some of the most popular tools to enhance the WordPress meta-data handling experience are <a href="http://wordpress.org/plugins/advanced-custom-fields/">Advanced Custom Fields</a>, <a href="https://wordpress.org/plugins/pods/">Pods</a>, <a href="https://wordpress.org/plugins/custom-field-suite/">Custom Field Suite</a>, and more. There are also many classes that are meant to be dropped into a custom theme or plugin.<span id="more-6809"></span></p>
<p>What&#8217;s happened is that these tools have taken different approaches, and over time some of them even change the way they store the data. This means that backward compatibly issues can arise, and if not handled properly, can cause problems for developers and site owners using these tools.</p>
<p>Trust me, I&#8217;m not trying to pin these issues on WordPress core. Developers should be careful about the tools they use, and builders of these tools should consider the backward compatibility issues their users may run into.</p>
<h3>A real life example happening right now</h3>
<p>I&#8217;ve spent some time in the last day or so trying to learn exactly what problems people are having with the upcoming changes to <a href="http://wordpress.org/plugins/advanced-custom-fields/">Advanced Custom Fields</a> (ACF). ACF has fast grown into one of the most popular tools for creating custom metaboxes and fields.</p>
<p>Advanced Custom Fields also has paid add-ons so the developer can monetize the work he&#8217;s put into the plugin.</p>
<p>The problem is, as <a href="http://chrislema.com/backward-compatibility-advanced-custom-fields/">Chris Lema did a great job of explaining</a>, is that he has not considered backward compatibility properly.</p>
<p>Basically, developers use ACF to build custom interfaces for their clients. Now, <a href="http://www.advancedcustomfields.com/blog/acf-pro-developer-launch/">ACF is changing</a> the add-on model to be a single Pro plugin, that&#8217;s not an add-on at all, but a whole new plugin.</p>
<p>While he&#8217;s at it, it&#8217;s very confusing what will work and not work between ACF versions 4 and 5, leaving developers confused, and worst of all, many site owners may upgrade to version 5 of the free plugin and see features disappear or their sites break.</p>
<p>This is not good. And folks are unhappy. The developer of ACF should ensure that he&#8217;s created workarounds for those that upgrade from version 4 to 5, that he doesn&#8217;t break their sites.</p>
<p>Worst of all, this isn&#8217;t the first time this has happened for ACF. When going from version 3 to 4, there were backward compatibility issues, and it was a tough upgrade on a lot of developers and site owners. It resulted in a fork of ACF, and <a href="https://wordpress.org/plugins/custom-field-suite/">Custom Field Suite</a> was born.</p>
<p>There&#8217;s a saying: &#8220;Fool me once, shame on you; fool me twice, shame on me.&#8221;</p>
<p>After the last time, I would&#8217;ve put the brakes on my level of trust that ACF would properly consider back compat moving forward. However, whether they should&#8217;ve kept using it or not, a lot of people are worried now about the future integrity of websites they built that depend on ACF.</p>
<h3>Backward compatibility is important</h3>
<p>Backward compatibility is important in WordPress. As a WordPress developer I talked to this morning noted, we&#8217;ve been training our clients for years that it&#8217;s safe to update their WordPress sites. And with irresponsible development practices, it puts that trust in jeopardy.</p>
<p>So I encourage two things:</p>
<ol>
<li>I hope that Elliot from ACF will re-consider the strategy he&#8217;s using, so that ACF users can have a more seamless upgrade. And I hope he&#8217;ll document exactly what actions users and developers should take (the existing posts and documentation is very confusing).</li>
<li>Developers need to strongly consider the tools they&#8217;re using, and determine whether it&#8217;s worth creating a dependency on a tool like ACF to make life a little easier during development.</li>
</ol>
<h3>It&#8217;s time for WordPress core to enhance the metadata API</h3>
<p>Many times with software, it&#8217;s tough to know exactly how people will use things. In the case of WordPress&#8217; custom fields, I doubt the core team really considered exactly how people would be using custom fields and the post meta table 5 or 8 years from then.</p>
<p>But today, the post meta table is a huge part of WordPress. It&#8217;s pivotal to storing data from interfaces that allow WordPress to be used as much more than &#8220;just a blogging platform.&#8221;</p>
<p>And I believe it&#8217;s high time core supports a common format for creating metadata UI interfaces.</p>
<p>Thankfully this process is already underway.</p>
<p>One of the WordPress core <a href="http://make.wordpress.org/core/components/">components</a> that&#8217;s being actively worked on is that for <a href="http://make.wordpress.org/core/components/options-meta/">WordPress Options and Meta APIs</a>. The aforementioned Scott Kingsley Clark (also the lead developer of Pods) is heading up the team, and they are utilizing regular meeting times to organize the project.</p>
<p>Most of the people involved in this core component have either created their own metadata framework or utilize metadata extensively in their own work. The massive spreadsheet comparison of existing tools was the first part of the process, to see how people are approaching it now, and analyze what the best route for a core solution would be.</p>
<p>In its current state, the new metadata API would make it easier than it currently is to create new fields and field groups to utilize a variety of core-supported field types. Furthermore, the new API would be extensible so that developers could utilize a core-supported framework to take custom fields even further.</p>
<p>You can check out more on their <a href="https://github.com/wordpress-metadata/metadata-ui-api">Github page</a> for more specific information, but something like this is really promising, and could be a game-changer for creating WordPress content if and when it goes into core.</p>
<h3>Make it easier for developers, and better for everyone</h3>
<p>Creating custom content types was possible before WordPress 3.0. But WordPress 3.0 made it so much easier, and clearer to folks with less development experience.</p>
<p>The metadata API already does a great job at making it easy to grab and use metadata. But creating beautiful custom metaboxes in the admin to enhance the publishing experience in WordPress is still relatively difficult. It&#8217;s totally possible, but I think it could be easier.</p>
<p>I strongly believe that an enhanced API to make it as easy as making WordPress custom post types would make WordPress a better, more reliable platform, and I think that most developers would be ecstatic to utilize a core API, versus attempting to choose amongst the fragmented metadata API landscape that exists today.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 07 Jul 2014 21:32:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: WordPress 4.0 to Add Language Selection to Installation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=25819";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:174:"http://wptavern.com/wordpress-4-0-to-add-language-selection-to-installation?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-4-0-to-add-language-selection-to-installation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2843:"<p>WordPress 4.0 will be introducing some major <a href="http://wptavern.com/major-internationalization-improvements-planned-for-wordpress-4-0" target="_blank">internationalization improvements</a> that will make it much easier to set up and use the software in languages other than English. A few weeks ago, WordPress lead developer Andrew Nacin published a <a href="http://make.wordpress.org/core/2014/05/21/internationalization-goals-for-4-0/" target="_blank">plan</a> with internationalization goals for 4.0. <strong>&#8220;Only 5%-10% of the world speaks English,&#8221;</strong> Nacin <a href="https://twitter.com/dimensionmedia/status/483035345551106048" target="_blank">said at WordCamp Seattle</a> last month. &#8220;WordPress 4.0 during install will allow you to choose your language.”</p>
<p>This is the first goal on the list and is already in the WordPress trunk if you want to test it out. WordPress <a href="https://core.trac.wordpress.org/changeset/28774" target="_blank">checks for available languages</a> to populate the dropdown. The option to select a language is now the first thing you see when you install WordPress:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/wordpress-installation.jpeg" rel="prettyphoto[25819]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/07/wordpress-installation.jpeg?resize=865%2C534" alt="wordpress-installation" class="aligncenter size-full wp-image-25821" /></a></p>
<p>The language you select will be enabled immediately so that the installation process is easier for those using languages other than English:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/installation-page.jpg" rel="prettyphoto[25819]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/installation-page.jpg?resize=786%2C530" alt="installation-page" class="aligncenter size-full wp-image-25828" /></a></p>
<p>This seemingly small improvement to the installation process could bring a flood of new users who were previously deterred by having to install the software in English. Matt Mullenweg was recently <a href="http://joshspeaking.com/matt-mullenweg/" target="_blank">interviewed</a> by Josh Janssen in Melbourne where he noted that May 2014 marked the first time that non-English downloads of WordPress surpassed the number of English downloads. As the software is adopted by more non-English speaking users, its user is base becoming more representative of the languages spoken by the world&#8217;s population.</p>
<p>Internationalization improvements in 4.0 have the potential to profoundly change WordPress&#8217; global community. How long do you think it will be before the majority of WordPress installations are in Mandarin, Spanish, Hindi, or Arabic? How do you think that will change contribution to the project?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 07 Jul 2014 17:52:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:102:"Post Status: Week in review: VIP learning, Javascript pervasiveness, and changing lives with WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=6803";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:188:"http://www.poststat.us/week-review-vip-learning-javascript-wordpress-changing-lives/?utm_source=rss&utm_medium=rss&utm_campaign=week-review-vip-learning-javascript-wordpress-changing-lives";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7768:"<p><img class="aligncenter size-large wp-image-6769" src="http://www.poststat.us/wp-content/uploads/2014/06/week-in-review1-752x300.jpg" alt="week-in-review" width="752" height="300" />Welcome to the second &#8220;<a href="http://www.poststat.us/category/week-in-review/">Week in Review</a>&#8221; on Post Status, where I hope to offer up some of the things you may have missed in the last week or so.</p>
<h3>WP Sessions VIP</h3>
<p>My friend Brian Richards is going full-force with WP Sessions and its <a href="http://wpsessions.com/vip/">new VIP offering</a>. WP Sessions is a great way to learn specific WordPress topics from seasoned professionals. As <a href="http://wpsessions.com/new-vip-program/">announced</a> on the blog, the new VIP offering is a yearly membership to WP Sessions, and includes exclusive speaker interviews, consistent new content, member discounts for partner products, and a highly discounted price versus buying each session independently.</p>
<p>The <a href="http://wpsessions.com/vip-prices-announced/">pricing</a> is $297 per year, but this week, you get $50 off and the first 100 people get a clean $100 off. At any of those prices, <a href="http://wpsessions.com/vip/">WP Sessions VIP</a> is definitely a great offering for those that want to learn WordPress from some really smart people.</p>
<h3>Is Javascript taking over WordPress?</h3>
<p><a href="http://neliosoftware.com/javascript-taking-wordpress/">Jordi Cabot posed this question</a> after seeing a conversation on Twitter to try and confirm some quotes by Matt Mullenweg and Andrew Nacin about the likely future pervasiveness of Javascript code in WordPress core.</p>
<div id="attachment_6804" class="wp-caption aligncenter"><img class="size-large wp-image-6804" src="http://www.poststat.us/wp-content/uploads/2014/07/wp-php-vs-js-nelio-752x529.png" alt="PHP vs JS in WordPress" width="752" height="529" /><p class="wp-caption-text">PHP vs JS (src: <a href="http://neliosoftware.com/javascript-taking-wordpress/">Nelio</a>)</p></div>
<p>Jordi did some analysis, and while Javascript is growing in WordPress (especially as the foundation for a variety of features), it&#8217;s not quite &#8220;taking over&#8221;. But Jordi gives some great advice:</p>
<blockquote><p>So, JavaScript is not taking over WordPress (yet) but based on these numbers and Matt’s opinion, it seems that if you want to call yourself a WordPress Developer (btw, Google says that there are over 600.000 “WordPress Developers” pages indexed), you may want to start learning a little bit of JavaScript apart from PHP.</p></blockquote>
<h3>Get started freelancing in WordPress</h3>
<p>Curtis McHale was <a href="http://ithemes.com/2014/06/13/freelance-wordpress-developer-curtis-mchale/">interviewed on the iThemes blog</a>, where he shared some of his philosophies, and how he manages a successful freelance business.</p>
<p>From learning, to making money, to acquiring clients, to networking, Curtis has some really great advice here that we should <a href="http://ithemes.com/2014/06/13/freelance-wordpress-developer-curtis-mchale/">all read</a>.<span id="more-6803"></span></p>
<h3>Post style permalinks for WordPress custom post types</h3>
<p>Daniel Bachhuber <a href="https://twitter.com/danielbachhuber/status/484708400542932993">shared</a> a nice gist last week for a way to <a href="https://gist.github.com/danielbachhuber/8af274e2b7f21c8c3bb6">achieve &#8220;post&#8221; style permalinks for a custom post type</a>. More specifically, it allows the inclusion of date parameters in the URL. This is a handy one, for when you need it.</p>
<h3>WordPress hosting, reliably and at scale</h3>
<p>There were a couple of fun posts in the last week about hosting. On Review Signal, Kevin Ohashi explained his testing and configurations for <a href="http://reviewsignal.com/blog/2014/06/25/40-million-hits-a-day-on-wordpress-using-a-10-vps/">stretching a $10 per month VPS to its limits</a>. He was able to stretch it to allow (per his post title at least) 40 million hits per day, based on his peak concurrent visitor tests.</p>
<p>Scaling WordPress hosting is one thing. But achieving ultra-high reliability is often another (though related) thing. <a href="https://kinsta.com/blog/ultra-high-availability-wordpress-hosting-explained/">Mark Gavalda explains</a> what high-reliability means (at least according to his WordPress hosting company, Kinsta). I found his explanation &#8212; while a bit heavy on self-marketing &#8212; to be an interesting read about scaling hosting for high volume websites.</p>
<h3>Branding WordPress products</h3>
<p>What is branding anyway? This is the question the <a href="http://wpninjas.com/rebranding/">guys at WP Ninjas asked</a>, and learned, when they worked with a branding agency to reshape their own brand.</p>
<p>They learned some good lessons about the value of a brand, and how to reinforce your brand in everything you do.</p>
<p>In a related note, I saw Chris Christoff <a href="https://twitter.com/chriscct7/status/486032472732610564">tweeting</a> about the importance of good brand assets pages for companies. I completely agree, and it was one of the tips I gave when I offered up some <a title="Tips for marketing WordPress products" href="http://www.poststat.us/marketing-wordpress-products/">marketing tips for WordPress products</a> a while back.</p>
<h3>Alternate UX for managing page hierarchy and templates</h3>
<p>Sarah Gooding <a href="http://wptavern.com/clarity-plugin-helps-wordpress-users-navigate-page-hierarchy-and-preview-templates">highlighted an interesting plugin</a> on WP Tavern, called <a href="http://wordpress.org/plugins/clarity/">Clarity</a>. The plugin has an alternative workflow for setting hierarchy and page templates in WordPress pages. I&#8217;m not sure I&#8217;m in love with the concept, but I do think it&#8217;s an interesting topic, and perhaps something worth thinking about &#8212; as it is a bit hidden to new users in the current format to set hierarchy and templates in WordPress pages.</p>
<p>On the subject of pages and WP Tavern, Jeff Chandler also <a href="http://wptavern.com/wordpress-visual-page-and-website-builders-make-it-easy-to-create-ugly-sites">wrote an editorial</a> about how he things page builders tend to do as much harm as good; he thinks they equip users to make ugly websites. Well, that&#8217;s certainly true; &#8220;with great power comes great responsibility&#8221;, the quote goes. I think they have a lot of power personally, but a page builder is no alternative to good design. The discussion in the comments of this post is pretty good.</p>
<h3>WordPress gives you tools to change lives</h3>
<p>For an uplifting finish to the last week in review, definitely read Chris Lema&#8217;s post about how <a href="http://chrislema.com/wordpress-change-lives/">WordPress gives us tools to change lives</a>. In the end, our processes, tools, and other stuff is not near as important as our ability to positively impact those we work with and for.</p>
<blockquote><p>I get the incredible opportunity to show up, into someone’s life and/or business, and say yes.</p>
<p>I have a power they don’t have. I can make the pixels dance. I can make the code obey.</p>
<p>And I can bring their dreams to life.</p>
<p>All because of WordPress.</p></blockquote>
<hr />
<p>I hope everyone had a great weekend, and that those readers in the United States enjoyed their 4th of July holiday. I know I did.</p>
<p>The week ahead looks bright. Lots of news is already on the way, and I have some fun stuff in the pipeline, including an interview with someone I&#8217;ve looked up to for a long time.</p>
<p>Have a great week, and be sure to share this with your friends if you enjoyed it!</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 07 Jul 2014 17:34:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"Matt: WordPress gives you tools to change lives";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43856";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ma.tt/2014/07/wordpress-gives-you-tools-to-change-lives/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:133:"<p>Chris Lema writes on how <a href="http://chrislema.com/wordpress-change-lives/">WordPress gives you tools to change lives</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 07 Jul 2014 14:46:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: NSA Cast Wide Nets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43861";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2014/07/nsa-cast-wide-nets/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:883:"<p>You can now count on a &#8220;Snowden Sunday&#8221; every few weeks: some jaw-dropping revelation that if you had suggested it a few years ago people would have dismissed you as a tin-foil-hat-wearing paranoid. Now the hardest part is not becoming numb. Here&#8217;s the latest from The Washington Post: <a href="http://www.washingtonpost.com/world/national-security/in-nsa-intercepted-data-those-not-targeted-far-outnumber-the-foreigners-who-are/2014/07/05/8139adf8-045a-11e4-8572-4b1b969b6322_story.html">In NSA-intercepted data, those not targeted far outnumber the foreigners who are</a>. Bonus: <a href="http://www.washingtonpost.com/world/national-security/cia-employees-quest-to-release-information-destroyed-my-entire-career/2014/07/04/e95f7802-0209-11e4-8572-4b1b969b6322_story.html">CIA employee’s quest to release information ‘destroyed my entire career.’</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 07 Jul 2014 02:05:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WordPress.tv: Rachel Baker: Put Your Content to REST With WP-API";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36161";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wordpress.tv/2014/07/06/rachel-baker-put-your-content-to-rest-with-wp-api/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:676:"<div id="v-TBYRqWBd-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36161/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36161/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36161&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/07/06/rachel-baker-put-your-content-to-rest-with-wp-api/"><img alt="Rachel Baker: Put Your Content to REST With WP-API" src="http://videos.videopress.com/TBYRqWBd/video-da8ad33970_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 06 Jul 2014 18:39:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 13 Jul 2014 22:37:23 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"173583";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sun, 13 Jul 2014 22:30:17 GMT";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130910180210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (273, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1405334244', 'no') ; 
INSERT INTO `wp_options` VALUES (274, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1405291044', 'no') ; 
INSERT INTO `wp_options` VALUES (275, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1405334244', 'no') ; 
INSERT INTO `wp_options` VALUES (276, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Jul 2014 22:30:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"50539@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Displays Google Analytics Reports and Real-Time Statistics in your Dashboard. Automatically inserts the tracking code in every page of your website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 10 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Black Studio TinyMCE Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"31973@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Adds a WYSIWYG widget based on the standard TinyMCE WordPress visual editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 13 Jul 2014 22:37:24 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Sun, 13 Jul 2014 23:05:43 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Sun, 13 Jul 2014 22:30:43 +0000";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130910180210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (277, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1405334244', 'no') ; 
INSERT INTO `wp_options` VALUES (278, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1405291044', 'no') ; 
INSERT INTO `wp_options` VALUES (279, '_transient_timeout_plugin_slugs', '1405392402', 'no') ; 
INSERT INTO `wp_options` VALUES (280, '_transient_plugin_slugs', 'a:3:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:9:"hello.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (281, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1405334244', 'no') ; 
INSERT INTO `wp_options` VALUES (282, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/\'>WordPress 4.0 Beta 1</a> <span class="rss-date">July 10, 2014</span><div class="rssSummary">WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can […]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/07/13/dan-beil-how-not-to-develop-with-wordpress/\' title=\'\'>WordPress.tv: Dan Beil: How NOT to Develop (With WordPress)</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/07/13/andrei-chira-cum-mi-a-schimbat-wordpress-viat%CC%A6a/\' title=\'\'>WordPress.tv: Andrei Chira: Cum mi-a schimbat WordPress viața</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/07/13/ivan-potancok-less-bootstrap/\' title=\'\'>WordPress.tv: Ivan Potančok: Less, Bootstrap</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/woocommerce/\' class=\'dashboard-news-plugin-link\'>WooCommerce - excelling eCommerce</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=woocommerce&amp;_wpnonce=6591ddb199&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'WooCommerce - excelling eCommerce\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (305, '_transient_alexchavet_categories', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (306, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1405316774', 'yes') ; 
INSERT INTO `wp_options` VALUES (307, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4463";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2778";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2683";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2196";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2110";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1756";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1553";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1513";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1465";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1449";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1401";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1340";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1308";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1157";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1116";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1096";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"999";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"955";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"955";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"789";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"782";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"781";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"769";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"766";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"703";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"678";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"662";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"651";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"619";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"610";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"592";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"583";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"579";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"579";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"568";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"532";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"525";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"524";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"510";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"507";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (308, '_site_transient_timeout_theme_roots', '1405307791', 'yes') ; 
INSERT INTO `wp_options` VALUES (309, '_site_transient_theme_roots', 'a:4:{s:10:"alexchavet";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (310, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1405306000;s:7:"checked";a:3:{s:19:"akismet/akismet.php";s:5:"3.0.0";s:35:"backupwordpress/backupwordpress.php";s:5:"2.6.2";s:9:"hello.php";s:3:"1.6";}s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.1";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.1.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (311, 'hmbkp_default_path', '/Users/cyponthemic/Desktop/ARTWORKS/WORDPRESS/Code-challenge/Wordpress-Challenge/wp-content/backupwordpress-4c3a0fc375-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (312, 'hmbkp_path', '/Users/cyponthemic/Desktop/ARTWORKS/WORDPRESS/Code-challenge/Wordpress-Challenge/wp-content/backupwordpress-4c3a0fc375-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (313, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (314, 'hmbkp_schedule_default-1', 'a:5:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1405378800;s:11:"max_backups";i:14;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (315, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1405825200;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (316, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (317, '_transient_timeout_hmbkp_plugin_data', '1405392409', 'no') ; 
INSERT INTO `wp_options` VALUES (318, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":20:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.6.2";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:32:"//profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:34:"//profiles.wordpress.org/humanmade";s:7:"willmot";s:32:"//profiles.wordpress.org/willmot";s:13:"pauldewouters";s:38:"//profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:33:"//profiles.wordpress.org/joehoyle";s:7:"mattheu";s:32:"//profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:34:"//profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.7.3";s:6:"tested";s:5:"3.9.1";s:13:"compatibility";a:1:{s:5:"3.9.1";a:1:{s:5:"2.6.2";a:3:{i:0;i:92;i:1;i:12;i:2;i:11;}}}s:6:"rating";d:91.599999999999994315658113919198513031005859375;s:11:"num_ratings";i:713;s:7:"ratings";a:5:{i:5;i:580;i:4;i:66;i:3;i:13;i:2;i:8;i:1;i:46;}s:10:"downloaded";i:1096982;s:12:"last_updated";s:10:"2014-05-06";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:18:"http://bwp.hmn.md/";s:8:"sections";a:5:{s:11:"description";s:1433:"<p><a href="https://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">BackUpWordPress</a> will back up your entire site including your database and all your files on a schedule that suits you. Try it now to see how easy it is!</p>

<h4>Features</h4>

<ul>
<li>Super simple to use, no setup required.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Manage multiple schedules.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster backups if they are available.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your backups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted on GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:1083:"<ol>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' title=\'Click to view full-size screenshot 1\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' alt=\'backupwordpress screenshot 1\' />
		</a>		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' title=\'Click to view full-size screenshot 2\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' alt=\'backupwordpress screenshot 2\' />
		</a>		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' title=\'Click to view full-size screenshot 3\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' alt=\'backupwordpress screenshot 3\' />
		</a>		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:32377:"<h4>2.6.2</h4>

<ul>
<li>Reverts a change to how the home path is calculated as it caused issues on installs where wp-config.php was stored outside of web root. Props to @mikelittle for the bug report.</li>
</ul>

<h4>2.6.1</h4>

<ul>
<li>Bump minimum WP requirement to 3.7.3, the latest security release on the 3.7 branch.</li>
<li>Fix an issues that could cause schedule times to fail to account for timezone differences.</li>
<li>Add a nonce check to the schedule settings.</li>
<li>Fix a possible JS warning when removing an exclude rule.</li>
<li>Our unit tests now run in PHP 5.2 again.</li>
</ul>

<h4>2.6</h4>

<ul>
<li>It\'s now possible to choose the time and day that your schedule will run on.</li>
<li>Introduces several new unit tests around schedule timings.</li>
<li>Fixes a bug that could cause the hourly schedule to run constantly.</li>
<li>Improved the layout of the Constants help panel.</li>
<li>If the backup root directory is unreadable then the plugin will no longer function.</li>
<li>Update the backups table match the standard WordPress table styles.</li>
<li>Improved styling for the settings dialogue.</li>
<li>Improved styling for the Server Info help tab.</li>
<li>/s/back ups/backups.</li>
<li>Remove Deprecated call to <code>screen_icon</code>.</li>
<li>Updated French translation.</li>
<li>Update the <code>WP CLI</code> command to use the new method for registering command.</li>
<li>Reload the schedules when re-setting up the default schedules so they show up straight away.</li>
<li>s/dpesnt\'t/doesn\'t.</li>
<li>Only show the estimated total schedule size when editing an existing schedule.</li>
<li>Stop stripping 0 from the minutes on hourly backups so that backups at 10 (&#38; 20, etc.) past the hour correctly show.</li>
<li>Disable buttons whilst ajax requests are running.</li>
<li>Move spinners outside the buttons as they didn\'t look very good inside.</li>
<li>Improve the detection of the home path on multisite installs which have WordPress in a subdirectory.</li>
<li>Track the time that the running backup is started and display how long a backup has been running for.</li>
<li>Fix an issue that meant it wasn\'t possible to run multiple manual backups at the same time.</li>
<li>Many other minor improvements.</li>
</ul>

<h4>2.5</h4>

<ul>
<li>BackUpWordPress now requires WordPress 3.7.1 as a minimum.</li>
<li>Remove some old back-compat code that was required because we supported older WP versions.</li>
<li>It\'s now possible to change the email address that notification emails are sent from using the <code>hmbkp_from_email</code> filter.</li>
<li>The spinner is now retina!</li>
<li>Close the PHP Session before starting the backup process to work around the 1 request per session issue. Backup status will now work on sites which happen to call <code>session_start</code>.</li>
<li>Pass <code>max_execution_time</code> and the BackUpWordPress Plugin version back to support. * Include the users real name in support requests</li>
<li>Stop passing <code>$_SERVER</code> with support requests as it can contain things like <code>.htaccess</code> passwords on some server configurations.</li>
<li>Improve the display of the server info in the enable support popup.</li>
<li>New screenshots</li>
<li>Use <code>wp_safe_redirect</code> for internal redirects.</li>
<li>Use <code>wp_is_writable</code> instead of <code>is_writable</code>.</li>
</ul>

<h4>2.4.2</h4>

<ul>
<li>In WordPress Multisite the backups admin page is now located in Network admin instead of the wp-admin of the main site.</li>
<li>Fixed an issue with the new intercom support integration that could cause loading the backups page to timeout</li>
<li>Fixed 3 stray PHP warnings.</li>
<li>BackUpWordPress will now always be loaded before any BackUpWordPress Extensions.</li>
<li>Fixed an issue that could cause a long modal (excludes) to show underneath the WP admin bar.</li>
</ul>

<h4>2.4.1</h4>

<ul>
<li>Add missing colorbox images</li>
</ul>

<h4>2.4</h4>

<ul>
<li>Support for new premium extensions for storing backups in a variety of online services.</li>
<li>Exclude the WP DB Manager backups and WP Super Cache cache directories by default.</li>
<li>We now use Intercom to offer support directly from within the plugin, opt-in of course.</li>
<li>More i18n fixes / improvements.</li>
<li>We no longer show download links if your backups directory isn\'t web accessible.</li>
<li>Fix a bug that caused the plugin activation and deactivation hooks from firing.</li>
<li>Correctly handle <code>MYSQL TIMESTAMP</code> columns in database dumps.</li>
<li><code>mysqldump</code> and <code>zip</code> are now correctly recognised on SmartOS.</li>
<li>Schedule names are now translatable.</li>
<li>Avoid having to re-calculate the filesize when a schedules type is set.</li>
<li>Compatibility with WordPress 3.8</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number.</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error.</li>
<li>Save and close as separate buttons.</li>
<li>Fix bug that caused multiple notification emails.</li>
<li>Fixes typo in database option name.</li>
<li>Updated translations.</li>
<li>Improve PHP docblocks.</li>
<li>Make schedules class a singleton.</li>
<li>Exclude popular backup plugin folders by default.</li>
<li>Exclude version control folders by default.</li>
<li>Fix broken localisation.</li>
<li>Use <code>wp_safe_redirect</code> instead of <code>wp_redirect</code> for internal form submissions</li>
<li></li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4410:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>What if I want I want to back up my site to another destination?</strong></p>

<p>BackUpWordPress Pro supports Dropbox, Google Drive, Amazon S3, Rackspace, Azure, DreamObjects and FTP/SFTP. Check it out here: <a href="http://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">https://bwp.hmn.md</a></p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.2.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (319, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2810698422', 'no') ; 
INSERT INTO `wp_options` VALUES (320, '_transient_hmbkp_schedule_default-1_database_filesize', '1409024', 'no') ; 
INSERT INTO `wp_options` VALUES (321, '_transient_timeout_hmbkp_schedule_default-1_complete_filesize', '2810698668', 'no') ; 
INSERT INTO `wp_options` VALUES (322, '_transient_hmbkp_schedule_default-1_complete_filesize', '36194916', 'no') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (128 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 2, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (3, 2, '_wp_trash_meta_time', '1404776622') ; 
INSERT INTO `wp_postmeta` VALUES (4, 5, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 5, '_edit_lock', '1405293561:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 7, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (7, 7, '_edit_lock', '1405293567:1') ; 
INSERT INTO `wp_postmeta` VALUES (8, 9, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (9, 9, '_edit_lock', '1404776842:1') ; 
INSERT INTO `wp_postmeta` VALUES (10, 9, '_wp_trash_meta_status', 'draft') ; 
INSERT INTO `wp_postmeta` VALUES (11, 9, '_wp_trash_meta_time', '1404776886') ; 
INSERT INTO `wp_postmeta` VALUES (12, 11, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13, 11, '_edit_lock', '1405301170:1') ; 
INSERT INTO `wp_postmeta` VALUES (14, 13, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (15, 13, '_edit_lock', '1405303462:1') ; 
INSERT INTO `wp_postmeta` VALUES (16, 15, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (17, 15, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (18, 15, '_menu_item_object_id', '5') ; 
INSERT INTO `wp_postmeta` VALUES (19, 15, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (20, 15, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (21, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (22, 15, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (23, 15, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (25, 16, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (26, 16, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (27, 16, '_menu_item_object_id', '11') ; 
INSERT INTO `wp_postmeta` VALUES (28, 16, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (29, 16, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (30, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (31, 16, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (32, 16, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (34, 17, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (35, 17, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (36, 17, '_menu_item_object_id', '13') ; 
INSERT INTO `wp_postmeta` VALUES (37, 17, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (38, 17, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (39, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (40, 17, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (41, 17, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (52, 19, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (53, 19, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (54, 19, '_menu_item_object_id', '7') ; 
INSERT INTO `wp_postmeta` VALUES (55, 19, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (56, 19, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (57, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (58, 19, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (59, 19, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (60, 23, '_wp_attached_file', '2014/07/stripe.png') ; 
INSERT INTO `wp_postmeta` VALUES (61, 23, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (62, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4;s:6:"height";i:4;s:4:"file";s:18:"2014/07/stripe.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (63, 23, '_wp_attachment_is_custom_background', 'alexchavet') ; 
INSERT INTO `wp_postmeta` VALUES (64, 24, '_wp_attached_file', '2014/07/kindajean_@2X.png') ; 
INSERT INTO `wp_postmeta` VALUES (65, 24, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (66, 24, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:294;s:6:"height";i:294;s:4:"file";s:25:"2014/07/kindajean_@2X.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"kindajean_@2X-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (67, 24, '_wp_attachment_is_custom_background', 'alexchavet') ; 
INSERT INTO `wp_postmeta` VALUES (68, 1, '_edit_lock', '1405305653:1') ; 
INSERT INTO `wp_postmeta` VALUES (69, 28, '_wp_attached_file', '2014/07/H1-BG_02.png') ; 
INSERT INTO `wp_postmeta` VALUES (70, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:20:"2014/07/H1-BG_02.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"H1-BG_02-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (71, 1, '_thumbnail_id', '100') ; 
INSERT INTO `wp_postmeta` VALUES (72, 1, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (85, 33, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (86, 33, '_edit_lock', '1405303878:1') ; 
INSERT INTO `wp_postmeta` VALUES (89, 35, '_wp_attached_file', '2014/07/H1-BG_04.png') ; 
INSERT INTO `wp_postmeta` VALUES (90, 35, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:20:"2014/07/H1-BG_04.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"H1-BG_04-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (98, 39, '_wp_attached_file', '2014/07/Good-Talent-Media-training-Melbourne-1-e1404870684967.png') ; 
INSERT INTO `wp_postmeta` VALUES (99, 39, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:836;s:6:"height";i:683;s:4:"file";s:65:"2014/07/Good-Talent-Media-training-Melbourne-1-e1404870684967.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:65:"Good-Talent-Media-training-Melbourne-1-e1404870684967-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:65:"Good-Talent-Media-training-Melbourne-1-e1404870684967-300x245.png";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (100, 39, '_wp_attachment_image_alt', 'Good Talent - Home page') ; 
INSERT INTO `wp_postmeta` VALUES (101, 40, '_wp_attached_file', '2014/07/Contact-us-Good-Talent.png') ; 
INSERT INTO `wp_postmeta` VALUES (102, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:769;s:6:"height";i:639;s:4:"file";s:34:"2014/07/Contact-us-Good-Talent.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"Contact-us-Good-Talent-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:34:"Contact-us-Good-Talent-300x249.png";s:5:"width";i:300;s:6:"height";i:249;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (103, 41, '_wp_attached_file', '2014/07/Corporate-Good-Talent.png') ; 
INSERT INTO `wp_postmeta` VALUES (104, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:795;s:6:"height";i:639;s:4:"file";s:33:"2014/07/Corporate-Good-Talent.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"Corporate-Good-Talent-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:33:"Corporate-Good-Talent-300x241.png";s:5:"width";i:300;s:6:"height";i:241;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (105, 42, '_wp_attached_file', '2014/07/Good-Talent-Media-training-Melbourne-2.png') ; 
INSERT INTO `wp_postmeta` VALUES (106, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1137;s:6:"height";i:487;s:4:"file";s:50:"2014/07/Good-Talent-Media-training-Melbourne-2.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-2-300x128.png";s:5:"width";i:300;s:6:"height";i:128;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:51:"Good-Talent-Media-training-Melbourne-2-1024x438.png";s:5:"width";i:1024;s:6:"height";i:438;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (107, 40, '_wp_attachment_image_alt', 'Good Talent - Contact us') ; 
INSERT INTO `wp_postmeta` VALUES (108, 41, '_wp_attachment_image_alt', 'Good Talent - Corporate') ; 
INSERT INTO `wp_postmeta` VALUES (109, 42, '_wp_attachment_image_alt', 'Good Talent - Footer') ; 
INSERT INTO `wp_postmeta` VALUES (110, 43, '_wp_attached_file', '2014/07/Good-Talent-Media-training-Melbourne-5.png') ; 
INSERT INTO `wp_postmeta` VALUES (111, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:577;s:4:"file";s:50:"2014/07/Good-Talent-Media-training-Melbourne-5.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-5-207x300.png";s:5:"width";i:207;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (112, 44, '_wp_attached_file', '2014/07/Good-Talent-Media-training-Melbourne-4.png') ; 
INSERT INTO `wp_postmeta` VALUES (113, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:577;s:4:"file";s:50:"2014/07/Good-Talent-Media-training-Melbourne-4.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-4-207x300.png";s:5:"width";i:207;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (114, 45, '_wp_attached_file', '2014/07/Good-Talent-Media-training-Melbourne-3.png') ; 
INSERT INTO `wp_postmeta` VALUES (115, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:639;s:4:"file";s:50:"2014/07/Good-Talent-Media-training-Melbourne-3.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-3-187x300.png";s:5:"width";i:187;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (116, 45, '_wp_attachment_image_alt', 'Good Talent - Home page (mobile)') ; 
INSERT INTO `wp_postmeta` VALUES (117, 44, '_wp_attachment_image_alt', 'Good Talent - Footer (mobile)') ; 
INSERT INTO `wp_postmeta` VALUES (118, 43, '_wp_attachment_image_alt', 'Good Talent - Mobile menu') ; 
INSERT INTO `wp_postmeta` VALUES (123, 39, '_wp_attachment_backup_sizes', 'a:5:{s:14:"thumbnail-orig";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:23:"thumbnail-1404870510473";a:4:{s:4:"file";s:65:"Good-Talent-Media-training-Melbourne-1-e1404870176649-150x122.png";s:5:"width";i:150;s:6:"height";i:122;s:9:"mime-type";s:9:"image/png";}s:9:"full-orig";a:3:{s:5:"width";i:836;s:6:"height";i:683;s:4:"file";s:42:"Good-Talent-Media-training-Melbourne-1.png";}s:23:"thumbnail-1404870684967";a:4:{s:4:"file";s:65:"Good-Talent-Media-training-Melbourne-1-e1404870510473-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"medium-orig";a:4:{s:4:"file";s:50:"Good-Talent-Media-training-Melbourne-1-300x245.png";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (126, 33, '_thumbnail_id', '39') ; 
INSERT INTO `wp_postmeta` VALUES (131, 61, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (132, 61, '_edit_lock', '1404903775:1') ; 
INSERT INTO `wp_postmeta` VALUES (133, 61, '_thumbnail_id', '76') ; 
INSERT INTO `wp_postmeta` VALUES (136, 63, '_wp_attached_file', '2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3-e1404900767719.png') ; 
INSERT INTO `wp_postmeta` VALUES (137, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:555;s:6:"height";i:555;s:4:"file";s:90:"2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3-e1404900767719.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:90:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3-e1404900767719-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:90:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3-e1404900767719-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (138, 64, '_wp_attached_file', '2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2-e1404900722232.png') ; 
INSERT INTO `wp_postmeta` VALUES (139, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:555;s:6:"height";i:555;s:4:"file";s:90:"2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2-e1404900722232.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:90:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2-e1404900722232-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:90:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2-e1404900722232-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (140, 65, '_wp_attached_file', '2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1-e1404900640884.png') ; 
INSERT INTO `wp_postmeta` VALUES (141, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:555;s:6:"height";i:555;s:4:"file";s:90:"2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1-e1404900640884.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:90:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1-e1404900640884-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:90:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1-e1404900640884-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (142, 66, '_wp_attached_file', '2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-.png') ; 
INSERT INTO `wp_postmeta` VALUES (143, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:751;s:6:"height";i:637;s:4:"file";s:74:"2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:74:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge--250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:74:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge--300x254.png";s:5:"width";i:300;s:6:"height";i:254;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (144, 67, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-6.png') ; 
INSERT INTO `wp_postmeta` VALUES (145, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:637;s:4:"file";s:36:"2014/07/Flexbox-Code-Challenge-6.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-6-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-6-188x300.png";s:5:"width";i:188;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (146, 68, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-5.png') ; 
INSERT INTO `wp_postmeta` VALUES (147, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:637;s:4:"file";s:36:"2014/07/Flexbox-Code-Challenge-5.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-5-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-5-188x300.png";s:5:"width";i:188;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (160, 68, '_wp_attachment_image_alt', 'Flexbox - Scroll bar mobile') ; 
INSERT INTO `wp_postmeta` VALUES (161, 74, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-9.png') ; 
INSERT INTO `wp_postmeta` VALUES (162, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1238;s:6:"height";i:637;s:4:"file";s:36:"2014/07/Flexbox-Code-Challenge-9.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-9-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-9-300x154.png";s:5:"width";i:300;s:6:"height";i:154;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:37:"Flexbox-Code-Challenge-9-1024x526.png";s:5:"width";i:1024;s:6:"height";i:526;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (163, 75, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-8.png') ; 
INSERT INTO `wp_postmeta` VALUES (164, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1238;s:6:"height";i:637;s:4:"file";s:36:"2014/07/Flexbox-Code-Challenge-8.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-8-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-8-300x154.png";s:5:"width";i:300;s:6:"height";i:154;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:37:"Flexbox-Code-Challenge-8-1024x526.png";s:5:"width";i:1024;s:6:"height";i:526;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (165, 76, '_wp_attached_file', '2014/07/Flexbox-Code-Challenge-7.png') ; 
INSERT INTO `wp_postmeta` VALUES (166, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1238;s:6:"height";i:637;s:4:"file";s:36:"2014/07/Flexbox-Code-Challenge-7.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-7-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:36:"Flexbox-Code-Challenge-7-300x154.png";s:5:"width";i:300;s:6:"height";i:154;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:37:"Flexbox-Code-Challenge-7-1024x526.png";s:5:"width";i:1024;s:6:"height";i:526;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (167, 76, '_wp_attachment_image_alt', 'Flexbox - Top page') ; 
INSERT INTO `wp_postmeta` VALUES (168, 65, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:751;s:6:"height";i:637;s:4:"file";s:67:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1.png";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:75:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:11:"medium-orig";a:4:{s:4:"file";s:75:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1-300x254.png";s:5:"width";i:300;s:6:"height";i:254;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (169, 64, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:751;s:6:"height";i:637;s:4:"file";s:67:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2.png";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:75:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:11:"medium-orig";a:4:{s:4:"file";s:75:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2-300x254.png";s:5:"width";i:300;s:6:"height";i:254;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (170, 63, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:751;s:6:"height";i:637;s:4:"file";s:67:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3.png";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:75:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:11:"medium-orig";a:4:{s:4:"file";s:75:"Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3-300x254.png";s:5:"width";i:300;s:6:"height";i:254;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (171, 67, '_wp_attachment_image_alt', 'Flexbox - Scroll bar mobile') ; 
INSERT INTO `wp_postmeta` VALUES (172, 75, '_wp_attachment_image_alt', 'Flexbox - Music section') ; 
INSERT INTO `wp_postmeta` VALUES (173, 74, '_wp_attachment_image_alt', 'Flexbox - Movies section') ; 
INSERT INTO `wp_postmeta` VALUES (174, 66, '_wp_attachment_image_alt', 'Flexbox - Top page') ; 
INSERT INTO `wp_postmeta` VALUES (175, 65, '_wp_attachment_image_alt', 'Flexbox - Music') ; 
INSERT INTO `wp_postmeta` VALUES (176, 64, '_wp_attachment_image_alt', 'Flexbox - Movies') ; 
INSERT INTO `wp_postmeta` VALUES (177, 63, '_wp_attachment_image_alt', 'Footer - Contact page') ; 
INSERT INTO `wp_postmeta` VALUES (188, 98, '_wp_attached_file', '2014/07/Concept-Home_04.png') ; 
INSERT INTO `wp_postmeta` VALUES (189, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1152;s:6:"height";i:504;s:4:"file";s:27:"2014/07/Concept-Home_04.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Concept-Home_04-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Concept-Home_04-300x131.png";s:5:"width";i:300;s:6:"height";i:131;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:28:"Concept-Home_04-1024x448.png";s:5:"width";i:1024;s:6:"height";i:448;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (190, 99, '_wp_attached_file', '2014/07/Concept-Home_03.png') ; 
INSERT INTO `wp_postmeta` VALUES (191, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1152;s:6:"height";i:1014;s:4:"file";s:27:"2014/07/Concept-Home_03.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Concept-Home_03-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Concept-Home_03-300x264.png";s:5:"width";i:300;s:6:"height";i:264;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:28:"Concept-Home_03-1024x901.png";s:5:"width";i:1024;s:6:"height";i:901;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (192, 100, '_wp_attached_file', '2014/07/Concept-Home_01.png') ; 
INSERT INTO `wp_postmeta` VALUES (193, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1152;s:6:"height";i:822;s:4:"file";s:27:"2014/07/Concept-Home_01.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Concept-Home_01-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Concept-Home_01-300x214.png";s:5:"width";i:300;s:6:"height";i:214;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:28:"Concept-Home_01-1024x730.png";s:5:"width";i:1024;s:6:"height";i:730;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (194, 101, '_wp_attached_file', '2014/07/Concept-Home_02.png') ; 
INSERT INTO `wp_postmeta` VALUES (195, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1152;s:6:"height";i:576;s:4:"file";s:27:"2014/07/Concept-Home_02.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Concept-Home_02-250x250.png";s:5:"width";i:250;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Concept-Home_02-300x150.png";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:28:"Concept-Home_02-1024x512.png";s:5:"width";i:1024;s:6:"height";i:512;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (95 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-07-07 23:24:36', '2014-07-07 23:24:36', 'For a personal challenge, I re-design the home page of a friend website.

<!--more-->

I found the website to colorful and difficult to read. so I tried to soften the colors and separate the section more clearly.

<a href="http://biomaster.com.au">biomaster.com.au </a>

Gallery:
[gallery ids="98,99,100,101"]
', 'Biomaster', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-07-14 02:17:02', '2014-07-14 02:17:02', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-07-07 23:24:36', '2014-07-07 23:24:36', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2014-07-07 23:43:42', '2014-07-07 23:43:42', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (3, 1, '2014-07-07 23:26:15', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-07-07 23:26:15', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=3', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2014-07-07 23:43:42', '2014-07-07 23:43:42', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-07-07 23:43:42', '2014-07-07 23:43:42', '', 2, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=4', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2014-07-07 23:45:36', '2014-07-07 23:45:36', '<h1 style="text-align: center;">Wordpress Challenge</h1>
<h2 style="text-align: center;">Welcome to my project !</h2>
<h3>I\'m going to detail below the different modification of function.php</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h3>Lorem ipsum dolor sit amet</h3>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-07-13 23:21:43', '2014-07-13 23:21:43', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?page_id=5', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-07-07 23:45:37', '2014-07-07 23:45:37', '<h1>Lorem ipsum dolor sit amet</h1>
<h2>Lorem ipsum dolor sit amet</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h2>Lorem ipsum dolor sit amet</h2>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-07-07 23:45:37', '2014-07-07 23:45:37', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=6', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-07-07 23:47:16', '2014-07-07 23:47:16', '<h1 style="text-align: center;">My projects</h1>
<h2>I decided to present them using blog posts, due to the contest restrictions.</h2>', 'Portofolio', '', 'publish', 'open', 'open', '', 'portofolio', '', '', '2014-07-13 23:21:16', '2014-07-13 23:21:16', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?page_id=7', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-07-07 23:47:16', '2014-07-07 23:47:16', '<h1>Portofolio</h1>
<h2>I decided to present my projects using blog posts, due to the contest restrictions.</h2>', 'Portofolio', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-07-07 23:47:16', '2014-07-07 23:47:16', '', 7, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=8', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2014-07-07 23:47:22', '2014-07-07 23:47:22', '', 'About', '', 'trash', 'open', 'open', '', 'about', '', '', '2014-07-07 23:48:06', '2014-07-07 23:48:06', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?page_id=9', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-07-07 23:48:06', '2014-07-07 23:48:06', '', 'About', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-07-07 23:48:06', '2014-07-07 23:48:06', '', 9, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=10', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-07-07 23:54:15', '2014-07-07 23:54:15', '<h1 style="text-align: center;">The rules of the contest.</h1>
<h2 style="text-align: center;">Here are the instructions:</h2>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'publish', 'open', 'open', '', 'about-2', '', '', '2014-07-13 23:22:00', '2014-07-13 23:22:00', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?page_id=11', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-07-07 23:54:15', '2014-07-07 23:54:15', '<h1>About</h1>
<h2>This Wordpress theme has been made in order to participate at a code challenge on Treehouse.</h2>
<h3>Here are the instructions:</h3>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-07-07 23:54:15', '2014-07-07 23:54:15', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=12', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-07-08 00:01:38', '2014-07-08 00:01:38', '<h1 style="text-align: center;">My name is Alex Chavet</h1>
<h2 style="text-align: center;">I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
<i class="fi-mail"></i>alex.chavet@gmail.com

<i class="fi-social-github"></i>cyponthemic

<i class="fi-social-treehouse"></i>alexchavet', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-07-14 02:06:42', '2014-07-14 02:06:42', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?page_id=13', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2014-07-08 00:01:38', '2014-07-08 00:01:38', '<h1>My name is Alex Chavet</h1>
<h2>I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
<h3>alex.chavet@gmail.com</h3>
<h3>cyponthemic</h3>
<h3>alexchavet</h3>', 'Contact', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-07-08 00:01:38', '2014-07-08 00:01:38', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=14', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2014-07-08 00:05:58', '2014-07-08 00:05:58', ' ', '', '', 'publish', 'open', 'open', '', '15', '', '', '2014-07-08 00:25:41', '2014-07-08 00:25:41', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=15', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2014-07-08 00:05:59', '2014-07-08 00:05:59', ' ', '', '', 'publish', 'open', 'open', '', '16', '', '', '2014-07-08 00:25:41', '2014-07-08 00:25:41', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=16', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2014-07-08 00:05:59', '2014-07-08 00:05:59', ' ', '', '', 'publish', 'open', 'open', '', '17', '', '', '2014-07-08 00:25:41', '2014-07-08 00:25:41', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=17', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2014-07-08 00:05:59', '2014-07-08 00:05:59', ' ', '', '', 'publish', 'open', 'open', '', '19', '', '', '2014-07-08 00:25:41', '2014-07-08 00:25:41', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=19', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2014-07-09 07:05:18', '2014-07-09 07:05:18', '<h1>Wordpress Challenge</h1>
<h2>Welcome to my entry !</h2>
I\'m going to detail below the different modification of function.php

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h3>Lorem ipsum dolor sit amet</h3>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'inherit', 'closed', 'open', '', '5-autosave-v1', '', '', '2014-07-09 07:05:18', '2014-07-09 07:05:18', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/5-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2014-07-08 01:01:06', '2014-07-08 01:01:06', '<h2>Lorem ipsum dolor sit amet</h2>
<h3>Lorem ipsum dolor sit amet</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h3>Lorem ipsum dolor sit amet</h3>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'inherit', 'closed', 'open', '', '5-revision-v1', '', '', '2014-07-08 01:01:06', '2014-07-08 01:01:06', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-07-08 01:02:43', '2014-07-08 01:02:43', '<h2>This Wordpress theme has been made in order to participate at a code challenge on Treehouse.</h2>
<h3>Here are the instructions:</h3>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-revision-v1', '', '', '2014-07-08 01:02:43', '2014-07-08 01:02:43', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2014-07-08 08:45:46', '2014-07-08 08:45:46', 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/stripe.png', 'stripe.png', '', 'inherit', 'closed', 'open', '', 'stripe-png', '', '', '2014-07-08 08:45:46', '2014-07-08 08:45:46', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/stripe.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2014-07-08 08:48:44', '2014-07-08 08:48:44', 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/kindajean_@2X.png', 'kindajean_@2X.png', '', 'inherit', 'closed', 'open', '', 'kindajean_2x-png', '', '', '2014-07-08 08:48:44', '2014-07-08 08:48:44', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/kindajean_@2X.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2014-07-09 07:01:57', '2014-07-09 07:01:57', '<h1>My name is Alex Chavet</h1>
<h2>I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
alex.chavet@gmail.com

cyponthemic

alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-autosave-v1', '', '', '2014-07-09 07:01:57', '2014-07-09 07:01:57', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2014-07-09 00:14:18', '2014-07-09 00:14:18', '<h2>My name is Alex Chavet</h2>
<h2>I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
<h3>alex.chavet@gmail.com</h3>
<h3>cyponthemic</h3>
<h3>alexchavet</h3>', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-09 00:14:18', '2014-07-09 00:14:18', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2014-07-09 00:15:06', '2014-07-09 00:15:06', '<h2>My name is Alex Chavet</h2>
<h3>I\'m French 23 years old, living in Melbourne.</h3>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h3>Get in touch !</h3>
alex.chavet@gmail.com

cyponthemic

alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-09 00:15:06', '2014-07-09 00:15:06', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2014-07-09 00:22:34', '2014-07-09 00:22:34', '', 'H1-BG_02', '', 'inherit', 'closed', 'open', '', 'h1-bg_02', '', '', '2014-07-09 00:22:34', '2014-07-09 00:22:34', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/H1-BG_02.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2014-07-09 00:22:41', '2014-07-09 00:22:41', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-07-09 00:22:41', '2014-07-09 00:22:41', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2014-07-14 01:33:41', '2014-07-14 01:33:41', 'For a personal challenge, I re-design the home page of a friend website.

<!--more-->

The website was to colorful and it was difficult to understand the content, so I tried to soften the colors and split', 'Biomaster', '', 'inherit', 'closed', 'open', '', '1-autosave-v1', '', '', '2014-07-14 01:33:41', '2014-07-14 01:33:41', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/1-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-07-09 00:27:23', '2014-07-09 00:27:23', '<?php if ( has_post_thumbnail() ) {
	the_post_thumbnail();
} ?>
Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-07-09 00:27:23', '2014-07-09 00:27:23', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2014-07-09 00:28:02', '2014-07-09 00:28:02', '<?php if ( has_post_thumbnail() ) { 	the_post_thumbnail(); } ?>
Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-07-09 00:28:02', '2014-07-09 00:28:02', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2014-07-09 00:43:00', '2014-07-09 00:43:00', 'Here my first website

<!--more-->

I worked on this website with <a href="http://cameronboyle.com.au">Cameron Boyle</a>. He did all the design and I did the integration. This was a nice starting project, I\'ve learned a lot about Fondation 5 and Github.

Gallery:

[gallery ids="39,41,42,40,45,43,44"]', 'Good Talent', '', 'publish', 'closed', 'open', '', 'good-talent', '', '', '2014-07-14 02:13:39', '2014-07-14 02:13:39', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=33', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2014-07-09 00:43:00', '2014-07-09 00:43:00', 'Here my first website', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-07-09 00:43:00', '2014-07-09 00:43:00', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2014-07-09 00:43:27', '2014-07-09 00:43:27', '', 'H1-BG_04', '', 'inherit', 'closed', 'open', '', 'h1-bg_04', '', '', '2014-07-09 00:43:27', '2014-07-09 00:43:27', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/H1-BG_04.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2014-07-09 00:53:09', '2014-07-09 00:53:09', 'Here my first website
[gallery ids="35,28"]', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-07-09 00:53:09', '2014-07-09 00:53:09', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2014-07-09 00:54:23', '2014-07-09 00:54:23', 'Here my first website
Gallery:
[gallery ids="35,28"]', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-07-09 00:54:23', '2014-07-09 00:54:23', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2014-07-14 02:08:50', '2014-07-14 02:08:50', 'Here my first website

<!--more-->

I worked on this website with Cameron Boyle. He did all the design and I did the integration. This was a nice starting project, I\'ve learned a lot about Fondation 5 et
Gallery:

[gallery ids="39,41,42,40,45,43,44"]', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-autosave-v1', '', '', '2014-07-14 02:08:50', '2014-07-14 02:08:50', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2014-07-09 01:03:31', '2014-07-09 01:03:31', 'This a screenshot of the home page of goodtalent.com.au', 'Good Talent  - Home Page', 'Home Page', 'inherit', 'closed', 'open', '', 'good-talent-media-training-melbourne-1', '', '', '2014-07-09 01:03:31', '2014-07-09 01:03:31', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Good-Talent-Media-training-Melbourne-1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2014-07-09 01:07:00', '2014-07-09 01:07:00', 'This a screenshot of the contact page of goodtalent.com.au', 'Good Talent - Contact us  ', 'Contact Page', 'inherit', 'closed', 'open', '', 'contact-us-good-talent', '', '', '2014-07-09 01:07:00', '2014-07-09 01:07:00', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Contact-us-Good-Talent.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-07-09 01:07:00', '2014-07-09 01:07:00', 'This a screenshot of one the static page template of goodtalent.com.au', 'Good Talent - Corporate   ', 'Static Page Template', 'inherit', 'closed', 'open', '', 'corporate-good-talent', '', '', '2014-07-09 01:07:00', '2014-07-09 01:07:00', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Corporate-Good-Talent.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2014-07-09 01:07:01', '2014-07-09 01:07:01', 'This a screenshot of the footer template of goodtalent.com.au', 'Good Talent  - Footer', 'Footer Template', 'inherit', 'closed', 'open', '', 'good-talent-media-training-melbourne-2', '', '', '2014-07-09 01:07:01', '2014-07-09 01:07:01', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Good-Talent-Media-training-Melbourne-2.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2014-07-09 01:11:58', '2014-07-09 01:11:58', 'This a screenshot of the responsive menu (mobile version) of goodtalent.com.au', 'Good Talent  - Mobile menu', 'Mobile Version - Menu', 'inherit', 'closed', 'open', '', 'good-talent-media-training-melbourne-5', '', '', '2014-07-09 01:11:58', '2014-07-09 01:11:58', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Good-Talent-Media-training-Melbourne-5.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2014-07-09 01:11:58', '2014-07-09 01:11:58', 'This a screenshot of the responsive footer template (mobile version)  of goodtalent.com.au', 'Good Talent  - Footer (mobile)', 'Mobile Version - Footer', 'inherit', 'closed', 'open', '', 'good-talent-media-training-melbourne-4', '', '', '2014-07-09 01:11:58', '2014-07-09 01:11:58', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Good-Talent-Media-training-Melbourne-4.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2014-07-09 01:11:59', '2014-07-09 01:11:59', 'This a screenshot of the responsive home page (mobile version)  of goodtalent.com.au', 'Good Talent - Home page (mobile)', 'Mobile version - Home page', 'inherit', 'closed', 'open', '', 'good-talent-media-training-melbourne-3', '', '', '2014-07-09 01:11:59', '2014-07-09 01:11:59', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Good-Talent-Media-training-Melbourne-3.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2014-07-09 01:18:02', '2014-07-09 01:18:02', 'Here my first website
Gallery:
[gallery ids="39,41,42,40,45,43,44"]', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-07-09 01:18:02', '2014-07-09 01:18:02', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2014-07-09 01:20:08', '2014-07-09 01:20:08', 'Here my first website

<!--more-->
Gallery:

[gallery ids="39,41,42,40,45,43,44"]', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-07-09 01:20:08', '2014-07-09 01:20:08', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2014-07-09 06:58:03', '2014-07-09 06:58:03', '<h1>Lorem ipsum dolor sit amet</h1>
<h2>Lorem ipsum dolor sit amet</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h3>Lorem ipsum dolor sit amet</h3>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'inherit', 'closed', 'open', '', '5-revision-v1', '', '', '2014-07-09 06:58:03', '2014-07-09 06:58:03', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2014-07-09 07:00:46', '2014-07-09 07:00:46', '<h1>This Wordpress theme has been made in order to participate at a code challenge on Treehouse.</h1>
<h3>Here are the instructions:</h3>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-revision-v1', '', '', '2014-07-09 07:00:46', '2014-07-09 07:00:46', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2014-07-09 07:01:27', '2014-07-09 07:01:27', '<h1>This Wordpress theme has been made in order to participate at a code challenge on Treehouse.</h1>
<h2>Here are the instructions:</h2>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-revision-v1', '', '', '2014-07-09 07:01:27', '2014-07-09 07:01:27', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-07-09 07:01:58', '2014-07-09 07:01:58', '<h1>My name is Alex Chavet</h1>
<h2>I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
alex.chavet@gmail.com

cyponthemic

alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-09 07:01:58', '2014-07-09 07:01:58', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2014-07-09 07:03:07', '2014-07-09 07:03:07', '<h1 style="text-align: center;">My name is Alex Chavet</h1>
<h2 style="text-align: center;">I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
alex.chavet@gmail.com

cyponthemic

alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-09 07:03:07', '2014-07-09 07:03:07', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2014-07-09 07:05:19', '2014-07-09 07:05:19', '<h1>Wordpress Challenge</h1>
<h2>Welcome to my entry !</h2>
<h3>I\'m going to detail below the different modification of function.php</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h3>Lorem ipsum dolor sit amet</h3>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'inherit', 'closed', 'open', '', '5-revision-v1', '', '', '2014-07-09 07:05:19', '2014-07-09 07:05:19', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2014-07-09 07:05:48', '2014-07-09 07:05:48', '<h1 style="text-align: center;">Wordpress Challenge</h1>
<h2 style="text-align: center;">Welcome to my project !</h2>
<h3>I\'m going to detail below the different modification of function.php</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h3>Lorem ipsum dolor sit amet</h3>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'inherit', 'closed', 'open', '', '5-revision-v1', '', '', '2014-07-09 07:05:48', '2014-07-09 07:05:48', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2014-07-09 07:06:44', '2014-07-09 07:06:44', '<h1 style="text-align: center;">My projects</h1>
<h2 style="text-align: center;">I decided to present them using blog posts, due to the contest restrictions.</h2>', 'Portofolio', '', 'inherit', 'closed', 'open', '', '7-revision-v1', '', '', '2014-07-09 07:06:44', '2014-07-09 07:06:44', '', 7, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2014-07-09 07:10:50', '2014-07-09 07:10:50', '<h1>The rules of the contest.</h1>
<h2>Here are the instructions:</h2>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-autosave-v1', '', '', '2014-07-09 07:10:50', '2014-07-09 07:10:50', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2014-07-09 07:10:53', '2014-07-09 07:10:53', '<h1>The rules of the contest.</h1>
<h2>Here are the instructions:</h2>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-revision-v1', '', '', '2014-07-09 07:10:53', '2014-07-09 07:10:53', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2014-07-09 07:11:07', '2014-07-09 07:11:07', '<h1 style="text-align: center;">The rules of the contest.</h1>
<h2 style="text-align: center;">Here are the instructions:</h2>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-revision-v1', '', '', '2014-07-09 07:11:07', '2014-07-09 07:11:07', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2014-07-09 07:11:30', '2014-07-09 07:11:30', '<h1 style="text-align: center;">The rules of the contest.</h1>
<h2 style="text-align: center;">Here are the instructions:</h2>
<p style="text-align: justify;">This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.</p>

<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-revision-v1', '', '', '2014-07-09 07:11:30', '2014-07-09 07:11:30', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2014-07-09 09:18:19', '2014-07-09 09:18:19', '<p>Here my first entry for Treehouse code challenge.
The aim was to design a layout using the CSS Flexbox module.</p>
<!--more-->

<p>Thanks to flexbox I realized a top vertical "side-top-bar" which switch into an iPhone-like top bar on mobile. Just by switching the flex-direction of the wrapper from column to row. Which pass the content form left to bottom of the top bar.

I also apply a smooth scroll effect to animate the scrolling between each section.</p>
<h3>Using the code :</h3>
<code>
$(\'a[href^="#"]\').click(function(){
var the_id = $(this).attr("href"); 

$(\'html, body\').animate({
scrollTop:$(the_id).offset().top
}, \'slow\');
return false;
});
</code>
<br>
Gallery:

[gallery ids="76,75,74,67,66,65,64,63"]', 'Flex box challenge', '', 'publish', 'closed', 'open', '', 'flex-box-challenge', '', '', '2014-07-09 11:02:54', '2014-07-09 11:02:54', '', 0, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/?p=61', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2014-07-09 09:18:19', '2014-07-09 09:18:19', '', 'Flex box challenge', '', 'inherit', 'closed', 'open', '', '61-revision-v1', '', '', '2014-07-09 09:18:19', '2014-07-09 09:18:19', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/61-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2014-07-09 10:01:30', '2014-07-09 10:01:30', 'Screenshot of the contact page in mobile version.', 'Flexbox - Contact page', 'Contact page - mobile', 'inherit', 'closed', 'open', '', 'responsinator-localhost-8888-code-challenge-flexbox-challenge-3', '', '', '2014-07-09 10:01:30', '2014-07-09 10:01:30', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-3.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2014-07-09 10:01:32', '2014-07-09 10:01:32', 'Screenshot of the movie page in mobile version.', 'Flexbox - Movies', 'Movies section - Mobile', 'inherit', 'closed', 'open', '', 'responsinator-localhost-8888-code-challenge-flexbox-challenge-2', '', '', '2014-07-09 10:01:32', '2014-07-09 10:01:32', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-2.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2014-07-09 10:01:32', '2014-07-09 10:01:32', 'Screenshot of the music page in mobile version.', 'Flexbox - Music ', 'Music section - Mobile', 'inherit', 'closed', 'open', '', 'responsinator-localhost-8888-code-challenge-flexbox-challenge-1', '', '', '2014-07-09 10:01:32', '2014-07-09 10:01:32', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2014-07-09 10:01:33', '2014-07-09 10:01:33', 'Screenshot of the top page in mobile version.', 'Flexbox - Top page ', 'Top page - Mobile', 'inherit', 'closed', 'open', '', 'responsinator-localhost-8888-code-challenge-flexbox-challenge', '', '', '2014-07-09 10:01:33', '2014-07-09 10:01:33', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Responsinator-localhost-8888-Code-challenge-Flexbox-challenge-.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2014-07-09 10:01:34', '2014-07-09 10:01:34', 'Screenshot to zoom on the sticky scroll bar feature, iphone-like.', 'Flexbox - Scroll bar mobile', 'Scroll bar - Mobile', 'inherit', 'closed', 'open', '', 'flexbox-code-challenge-6', '', '', '2014-07-09 10:01:34', '2014-07-09 10:01:34', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Flexbox-Code-Challenge-6.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2014-07-09 10:01:34', '2014-07-09 10:01:34', 'Screenshot to zoom on the sticky scroll bar feature, iphone-like.', 'Flexbox - Scroll bar mobile', '', 'inherit', 'closed', 'open', '', 'flexbox-code-challenge-5', '', '', '2014-07-09 10:01:34', '2014-07-09 10:01:34', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Flexbox-Code-Challenge-5.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2014-07-09 10:07:29', '2014-07-09 10:07:29', 'Sreenchot of the Movies section in desktop version.
Embed youtube video appears when you click see trailer. ', 'Flexbox - Movies section', 'Movies - Desktop', 'inherit', 'closed', 'open', '', 'flexbox-code-challenge-9', '', '', '2014-07-09 10:07:29', '2014-07-09 10:07:29', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Flexbox-Code-Challenge-9.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2014-07-09 10:07:30', '2014-07-09 10:07:30', 'Sreenchot of the Music section in desktop version.
Embed from soundcloud.', 'Flexbox - Music section', 'Music - Desktop', 'inherit', 'closed', 'open', '', 'flexbox-code-challenge-8', '', '', '2014-07-09 10:07:30', '2014-07-09 10:07:30', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Flexbox-Code-Challenge-8.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2014-07-09 10:07:31', '2014-07-09 10:07:31', 'Screenshot of the header in desktop version.', 'Flexbox - Top page', 'Top page - Desktop', 'inherit', 'closed', 'open', '', 'flexbox-code-challenge-7', '', '', '2014-07-09 10:07:31', '2014-07-09 10:07:31', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Flexbox-Code-Challenge-7.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2014-07-09 10:36:31', '2014-07-09 10:36:31', 'Here my first entry for Treehouse code challenge.
The aim was to design a layout using the CSS Flexbox module.
<!--more-->
Thanks to flexbox I realized a top vertical "side-top-bar" which switch into an iPhone-like top bar on mobile. Just by switching the flex-direction of the wrapper from column to row. Which pass the content form left to bottom of the top bar.
I also apply a smooth scroll effect to animate the scrolling between each section. 
Using the code :
<code>

</code>
Gallery:
[gallery ids="76,75,74,67,66,65,64,63"]', 'Flex box challenge', '', 'inherit', 'closed', 'open', '', '61-autosave-v1', '', '', '2014-07-09 10:36:31', '2014-07-09 10:36:31', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/61-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2014-07-09 10:38:21', '2014-07-09 10:38:21', 'Here my first entry for Treehouse code challenge.
The aim was to design a layout using the CSS Flexbox module.
<!--more-->
<p>Thanks to flexbox I realized a top vertical "side-top-bar" which switch into an iPhone-like top bar on mobile. Just by switching the flex-direction of the wrapper from column to row. Which pass the content form left to bottom of the top bar.<br>
I also apply a smooth scroll effect to animate the scrolling between each section.</p>
<h3>Using the code :</h3>
<code>
$(\'a[href^="#"]\').click(function(){
var the_id = $(this).attr("href"); </code>

$(\'html, body\').animate({
scrollTop:$(the_id).offset().top
}, \'slow\');
return false;
});

Gallery:

[gallery ids="76,75,74,67,66,65,64,63"]', 'Flex box challenge', '', 'inherit', 'closed', 'open', '', '61-revision-v1', '', '', '2014-07-09 10:38:21', '2014-07-09 10:38:21', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/61-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2014-07-09 10:40:02', '2014-07-09 10:40:02', 'Here my first entry for Treehouse code challenge.
The aim was to design a layout using the CSS Flexbox module.
<!--more-->

Thanks to flexbox I realized a top vertical "side-top-bar" which switch into an iPhone-like top bar on mobile. Just by switching the flex-direction of the wrapper from column to row. Which pass the content form left to bottom of the top bar.

I also apply a smooth scroll effect to animate the scrolling between each section.
<h3>Using the code :</h3>
<code>
$(\'a[href^="#"]\').click(function(){
var the_id = $(this).attr("href"); </code>

$(\'html, body\').animate({
scrollTop:$(the_id).offset().top
}, \'slow\');
return false;
});

Gallery:

[gallery ids="76,75,74,67,66,65,64,63"]', 'Flex box challenge', '', 'inherit', 'closed', 'open', '', '61-revision-v1', '', '', '2014-07-09 10:40:02', '2014-07-09 10:40:02', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/61-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2014-07-09 10:46:14', '2014-07-09 10:46:14', '<p>Here my first entry for Treehouse code challenge.
The aim was to design a layout using the CSS Flexbox module.
<!--more-->

Thanks to flexbox I realized a top vertical "side-top-bar" which switch into an iPhone-like top bar on mobile. Just by switching the flex-direction of the wrapper from column to row. Which pass the content form left to bottom of the top bar.

I also apply a smooth scroll effect to animate the scrolling between each section.</p>
<h3>Using the code :</h3>
<code>
$(\'a[href^="#"]\').click(function(){
var the_id = $(this).attr("href"); </code>

$(\'html, body\').animate({
scrollTop:$(the_id).offset().top
}, \'slow\');
return false;
});

Gallery:

[gallery ids="76,75,74,67,66,65,64,63"]', 'Flex box challenge', '', 'inherit', 'closed', 'open', '', '61-revision-v1', '', '', '2014-07-09 10:46:14', '2014-07-09 10:46:14', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/61-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2014-07-09 10:46:52', '2014-07-09 10:46:52', '<p>Here my first entry for Treehouse code challenge.
The aim was to design a layout using the CSS Flexbox module.</p>
<!--more-->

<p>Thanks to flexbox I realized a top vertical "side-top-bar" which switch into an iPhone-like top bar on mobile. Just by switching the flex-direction of the wrapper from column to row. Which pass the content form left to bottom of the top bar.

I also apply a smooth scroll effect to animate the scrolling between each section.</p>
<h3>Using the code :</h3>
<code>
$(\'a[href^="#"]\').click(function(){
var the_id = $(this).attr("href"); </code>

$(\'html, body\').animate({
scrollTop:$(the_id).offset().top
}, \'slow\');
return false;
});

Gallery:

[gallery ids="76,75,74,67,66,65,64,63"]', 'Flex box challenge', '', 'inherit', 'closed', 'open', '', '61-revision-v1', '', '', '2014-07-09 10:46:52', '2014-07-09 10:46:52', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/61-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2014-07-09 10:48:49', '2014-07-09 10:48:49', '<h1 style="text-align: center;">My projects</h1>
<h3 style="text-align: center;">I decided to present them using blog posts, due to the contest restrictions.</h3>', 'Portofolio', '', 'inherit', 'closed', 'open', '', '7-revision-v1', '', '', '2014-07-09 10:48:49', '2014-07-09 10:48:49', '', 7, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2014-07-09 10:49:50', '2014-07-09 10:49:50', '<h1 style="text-align: center;">My projects</h1>
<h2 style="text-align: center;">I decided to present them using blog posts, due to the contest restrictions.</h3>', 'Portofolio', '', 'inherit', 'closed', 'open', '', '7-autosave-v1', '', '', '2014-07-09 10:49:50', '2014-07-09 10:49:50', '', 7, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/7-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2014-07-09 10:49:52', '2014-07-09 10:49:52', '<h1 style="text-align: center;">My projects</h1>
<h2 style="text-align: center;">I decided to present them using blog posts, due to the contest restrictions.</h2>', 'Portofolio', '', 'inherit', 'closed', 'open', '', '7-revision-v1', '', '', '2014-07-09 10:49:52', '2014-07-09 10:49:52', '', 7, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2014-07-09 11:02:54', '2014-07-09 11:02:54', '<p>Here my first entry for Treehouse code challenge.
The aim was to design a layout using the CSS Flexbox module.</p>
<!--more-->

<p>Thanks to flexbox I realized a top vertical "side-top-bar" which switch into an iPhone-like top bar on mobile. Just by switching the flex-direction of the wrapper from column to row. Which pass the content form left to bottom of the top bar.

I also apply a smooth scroll effect to animate the scrolling between each section.</p>
<h3>Using the code :</h3>
<code>
$(\'a[href^="#"]\').click(function(){
var the_id = $(this).attr("href"); 

$(\'html, body\').animate({
scrollTop:$(the_id).offset().top
}, \'slow\');
return false;
});
</code>
<br>
Gallery:

[gallery ids="76,75,74,67,66,65,64,63"]', 'Flex box challenge', '', 'inherit', 'closed', 'open', '', '61-revision-v1', '', '', '2014-07-09 11:02:54', '2014-07-09 11:02:54', '', 61, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/61-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2014-07-13 22:41:25', '2014-07-13 22:41:25', '<h1 style="text-align: center;">Wordpress Challenge</h1>
<h2 style="text-align: center;">Welcome to my project !</h2>
<h3>I\'m going to detail below the different modification of function.php</h3>
<p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.</p>

<h3>Lorem ipsum dolor sit amet</h3>
<p style="text-align: justify;">Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.</p>', 'Home', '', 'inherit', 'closed', 'open', '', '5-revision-v1', '', '', '2014-07-13 22:41:25', '2014-07-13 22:41:25', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2014-07-13 22:42:09', '2014-07-13 22:42:09', '<h1 style="text-align: center;">My name is Alex Chavet</h1>
<h2 style="text-align: center;">I\'m French 23 years old, living in Melbourne.</h2>
<p style="text-align: justify;">With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.</p>

<h2 style="text-align: justify;">Get in touch !</h2>
alex.chavet@gmail.com

cyponthemic

alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-13 22:42:09', '2014-07-13 22:42:09', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-07-13 22:44:05', '2014-07-13 22:44:05', '<h1 style="text-align: center;">My projects</h1>
<h2 style="text-align: justify;">I decided to present them using blog posts, due to the contest restrictions.</h2>', 'Portofolio', '', 'inherit', 'closed', 'open', '', '7-revision-v1', '', '', '2014-07-13 22:44:05', '2014-07-13 22:44:05', '', 7, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2014-07-13 23:21:16', '2014-07-13 23:21:16', '<h1 style="text-align: center;">My projects</h1>
<h2>I decided to present them using blog posts, due to the contest restrictions.</h2>', 'Portofolio', '', 'inherit', 'closed', 'open', '', '7-revision-v1', '', '', '2014-07-13 23:21:16', '2014-07-13 23:21:16', '', 7, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/7-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2014-07-13 23:21:30', '2014-07-13 23:21:30', '<h1 style="text-align: center;">My name is Alex Chavet</h1>
<h2 style="text-align: center;">I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
alex.chavet@gmail.com

cyponthemic

alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-13 23:21:30', '2014-07-13 23:21:30', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-07-13 23:21:43', '2014-07-13 23:21:43', '<h1 style="text-align: center;">Wordpress Challenge</h1>
<h2 style="text-align: center;">Welcome to my project !</h2>
<h3>I\'m going to detail below the different modification of function.php</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet justo euismod, dignissim tellus eu, luctus quam. Nullam porta aliquam ante, ac bibendum odio interdum in. Phasellus vitae porta libero. Integer at mi scelerisque, lobortis massa id, auctor felis. Integer ac nisi vitae tortor viverra faucibus sed venenatis velit. Nam eleifend pellentesque sapien. Morbi risus tortor, sagittis non metus imperdiet, auctor adipiscing nunc. Nam consequat arcu at lacinia sagittis. Vivamus sollicitudin purus non est fermentum, vel pulvinar turpis vehicula. Aliquam in luctus arcu. Aliquam sit amet elementum quam. Pellentesque eget orci ac nibh posuere ultricies quis nec turpis. Quisque scelerisque nec velit non pretium.
<h3>Lorem ipsum dolor sit amet</h3>
Morbi luctus, mi vel feugiat facilisis, felis elit pharetra nisi, in pulvinar magna felis quis nunc. Nullam fermentum facilisis ligula ut adipiscing. Vivamus dignissim bibendum metus, sed faucibus lacus hendrerit eget. Integer laoreet purus in dui pretium, id tristique felis lacinia. Nullam volutpat sem enim, nec placerat turpis molestie eu. Etiam malesuada velit at nulla porttitor, nec porttitor mi congue. Fusce vel turpis erat.', 'Home', '', 'inherit', 'closed', 'open', '', '5-revision-v1', '', '', '2014-07-13 23:21:43', '2014-07-13 23:21:43', '', 5, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/5-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-07-13 23:22:00', '2014-07-13 23:22:00', '<h1 style="text-align: center;">The rules of the contest.</h1>
<h2 style="text-align: center;">Here are the instructions:</h2>
This forum contest is designed to test off a person\'s front-end and back-end WordPress skills with a small project customizing the _S Underscores theme. In this contest you will start with a completely blank WordPress theme. Then use your front-end CSS skills to edit the main style.css file to design the best looking site you can. With your backend skills you can use the functions.php to enhance the functionality of your theme.
<ul>
	<li>First, download the _S Underscores theme from (http://underscores.me/)[http://underscores.me/] and install on a live server that you can link to</li>
	<li>Add whatever content you like using Posts and Pages, no custom post types. Set whatever settings you like, no plugins though.</li>
	<li>Style the site to the best of your ability editing only the main style.css file. No including external CSS ;)</li>
	<li>You can add code to the functions.php file, but you must be able to understand and explain what the code is doing.</li>
	<li>No editing any template files besides the style.css and functions.php</li>
</ul>', 'About', '', 'inherit', 'closed', 'open', '', '11-revision-v1', '', '', '2014-07-13 23:22:00', '2014-07-13 23:22:00', '', 11, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2014-07-14 01:35:19', '2014-07-14 01:35:19', 'For a personal challenge, I re-design the home page of a friend website.

<!--more-->

I found the website to colorful and difficult to read. so I tried to soften the colors and separate the section more clearly.

<a href="http://biomaster.com.au">biomaster.com.au </a>', 'Biomaster', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-07-14 01:35:19', '2014-07-14 01:35:19', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2014-07-14 01:43:44', '2014-07-14 01:43:44', '<h1 style="text-align: center;">My name is Alex Chavet</h1>
<h2 style="text-align: center;">I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>

<i class="fi-mail"></i>alex.chavet@gmail.com

cyponthemic

alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-14 01:43:44', '2014-07-14 01:43:44', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2014-07-14 01:46:46', '2014-07-14 01:46:46', '<h1 style="text-align: center;">My name is Alex Chavet</h1>
<h2 style="text-align: center;">I\'m French 23 years old, living in Melbourne.</h2>
With a business school background in France, I decided to try something new when I arrived in Melbourne. This city full of culture, art and inspiration made me turn into web-design. I\'ve learn everything from Treehouse for 4 moths, and I\'m trying to apply my knowledge with their code challenge.
<h2>Get in touch !</h2>
<i class="fi-mail"></i>alex.chavet@gmail.com

<i class="fi-social-github"></i>cyponthemic

<i class="fi-social-treehouse"></i>alexchavet', 'Contact', '', 'inherit', 'closed', 'open', '', '13-revision-v1', '', '', '2014-07-14 01:46:46', '2014-07-14 01:46:46', '', 13, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2014-07-14 02:08:56', '2014-07-14 02:08:56', 'Here my first website

<!--more-->

I worked on this website with Cameron Boyle. He did all the design and I did the integration. This was a nice starting project, I\'ve learned a lot about Fondation 5 and Github.

Gallery:

[gallery ids="39,41,42,40,45,43,44"]', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-07-14 02:08:56', '2014-07-14 02:08:56', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-07-14 02:09:30', '2014-07-14 02:09:30', 'Here my first website

<!--more-->

I worked on this website with <a href="http://cameronboyle.com.au">Cameron Boyle</a>. He did all the design and I did the integration. This was a nice starting project, I\'ve learned a lot about Fondation 5 and Github.

Gallery:

[gallery ids="39,41,42,40,45,43,44"]', 'Good Talent', '', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-07-14 02:09:30', '2014-07-14 02:09:30', '', 33, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/33-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-07-14 02:16:01', '2014-07-14 02:16:01', '', 'Concept---Home_04', '', 'inherit', 'closed', 'open', '', 'concept-home_04', '', '', '2014-07-14 02:16:01', '2014-07-14 02:16:01', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Concept-Home_04.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2014-07-14 02:16:02', '2014-07-14 02:16:02', '', 'Concept---Home_03', '', 'inherit', 'closed', 'open', '', 'concept-home_03', '', '', '2014-07-14 02:16:02', '2014-07-14 02:16:02', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Concept-Home_03.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2014-07-14 02:16:04', '2014-07-14 02:16:04', '', 'Concept---Home_01', '', 'inherit', 'closed', 'open', '', 'concept-home_01', '', '', '2014-07-14 02:16:04', '2014-07-14 02:16:04', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Concept-Home_01.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2014-07-14 02:16:05', '2014-07-14 02:16:05', '', 'Concept---Home_02', '', 'inherit', 'closed', 'open', '', 'concept-home_02', '', '', '2014-07-14 02:16:05', '2014-07-14 02:16:05', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/wp-content/uploads/2014/07/Concept-Home_02.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-07-14 02:16:41', '2014-07-14 02:16:41', 'For a personal challenge, I re-design the home page of a friend website.

<!--more-->

I found the website to colorful and difficult to read. so I tried to soften the colors and separate the section more clearly.

<a href="http://biomaster.com.au">biomaster.com.au </a>

Gallery:
[gallery ids="98,99,100,101"]
', 'Biomaster', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-07-14 02:16:41', '2014-07-14 02:16:41', '', 1, 'http://localhost:8888/Code-challenge/Wordpress-Challenge/1-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (7 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (15, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (16, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (17, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (19, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (33, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (61, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (5 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'nav_menu', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'post_format', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'post_format', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (5 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Main menu', 'main-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Footer', 'footer', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'post-format-aside', 'post-format-aside', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'post-format-image', 'post-format-image', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (23 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'alex_master') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_user-settings', 'editor=html&hidetb=1&libraryContent=browse') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings-time', '1405304197') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'closedpostboxes_post', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'metaboxhidden_post', 'a:7:{i:0;s:12:"revisionsdiv";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:11:"commentsdiv";i:5;s:7:"slugdiv";i:6;s:9:"authordiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'meta-box-order_page', 'a:3:{s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:70:"revisionsdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (23, 1, 'screen_layout_page', '2') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/Code-challenge/Wordpress-Challenge MySQL database backup
#
# Generated: Monday 14. July 2014 02:48 UTC
# Hostname: localhost
# Database: `wordpress_contest`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'alex_master', '$P$Bgr.AGOKkfEM5fkgJRmp5uYnmVbWXg1', 'alex_master', 'alex.chavet@gmail.com', '', '2014-07-07 23:24:36', '', 0, 'alex_master') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

